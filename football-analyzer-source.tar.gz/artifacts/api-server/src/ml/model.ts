import fs from 'fs';
import path from 'path';

export interface MLFeatureVector {
  homeWinRate: number;
  awayWinRate: number;
  homeAvgGoalsFor: number;
  awayAvgGoalsFor: number;
  homeAvgGoalsAgainst: number;
  awayAvgGoalsAgainst: number;
  homeRecentPoints: number;
  awayRecentPoints: number;
  homeTrend: number;
  awayTrend: number;
  homeXgFor: number;
  awayXgFor: number;
  h2hHomeWinRate: number;
  h2hAvgGoals: number;
  homeAdvantage: number;
  homePPG: number;
  awayPPG: number;
  homeGoalDiff: number;
  awayGoalDiff: number;
  formDiff: number;
}

export interface MLPrediction {
  homeWinProb: number;
  drawProb: number;
  awayWinProb: number;
  confidence: number;
  modelUsed: string;
  features: {
    homeForm: number;
    awayForm: number;
    h2hAdvantage: number;
    homeAdvantage: number;
  };
  available: boolean;
}

type Outcome = 0 | 1 | 2;

interface TrainingRecord {
  matchId: number;
  matchDate: string;
  features: MLFeatureVector;
  predictedProbs: [number, number, number];
  homeTeam: string;
  awayTeam: string;
  actualOutcome?: Outcome;
  homeGoals?: number;
  awayGoals?: number;
  trainedAt?: string;
}

interface ModelWeights {
  treeWeights: [number, number, number, number];
  featureWeights: {
    homeWinRateW: number;
    awayWinRateW: number;
    homeRecentW: number;
    awayRecentW: number;
    homeTrendW: number;
    awayTrendW: number;
    xgRatioW: number;
    h2hW: number;
    homeAdvW: number;
    ppgDiffW: number;
    gdDiffW: number;
  };
  homeAdvBias: number;
  drawCalibration: number;
  totalMatchesTrained: number;
  lastTrainedAt: string;
  accuracy7day: number;
  accuracy30day: number;
  lossHistory: number[];
  version: number;
}

interface ModelState {
  weights: ModelWeights;
  pendingPredictions: TrainingRecord[];
  completedRecords: TrainingRecord[];
}

const DATA_DIR = path.join(process.cwd(), '.ml-data');
const STATE_FILE = path.join(DATA_DIR, 'model-state.json');

function ensureDir() {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
}

const DEFAULT_WEIGHTS: ModelWeights = {
  treeWeights: [0.25, 0.30, 0.20, 0.25],
  featureWeights: {
    homeWinRateW: 1.0, awayWinRateW: 1.0, homeRecentW: 1.0, awayRecentW: 1.0,
    homeTrendW: 1.0, awayTrendW: 1.0, xgRatioW: 1.0, h2hW: 1.0,
    homeAdvW: 1.0, ppgDiffW: 1.0, gdDiffW: 1.0,
  },
  homeAdvBias: 0.05,
  drawCalibration: 0.22,
  totalMatchesTrained: 0,
  lastTrainedAt: new Date().toISOString(),
  accuracy7day: 0,
  accuracy30day: 0,
  lossHistory: [],
  version: 1,
};

function loadState(): ModelState {
  ensureDir();
  try {
    if (fs.existsSync(STATE_FILE)) {
      const raw = fs.readFileSync(STATE_FILE, 'utf-8');
      const parsed = JSON.parse(raw) as ModelState;
      parsed.weights = { ...DEFAULT_WEIGHTS, ...parsed.weights };
      parsed.weights.featureWeights = { ...DEFAULT_WEIGHTS.featureWeights, ...parsed.weights.featureWeights };
      return parsed;
    }
  } catch (err) {
    console.error('[ML] Failed to load model state:', err);
  }
  return { weights: { ...DEFAULT_WEIGHTS }, pendingPredictions: [], completedRecords: [] };
}

function saveState(s: ModelState) {
  ensureDir();
  try {
    s.completedRecords = s.completedRecords.slice(-200);
    fs.writeFileSync(STATE_FILE, JSON.stringify(s, null, 2), 'utf-8');
  } catch (err) {
    console.error('[ML] Failed to save model state:', err);
  }
}

let state: ModelState = loadState();

function forwardPass(f: MLFeatureVector, w: ModelWeights): [number, number, number] {
  const fw = w.featureWeights;
  const t1H = 0.3 * f.homeWinRate * fw.homeWinRateW + 0.15 * f.homeRecentPoints * fw.homeRecentW - 0.1 * f.awayWinRate * fw.awayWinRateW + 0.15 * f.homeAdvantage * fw.homeAdvW;
  const t1D = w.drawCalibration - 0.05 * Math.abs(f.homeWinRate - f.awayWinRate) - 0.05 * f.homeTrend * fw.homeTrendW;
  const t1A = 0.3 * f.awayWinRate * fw.awayWinRateW + 0.1 * f.awayRecentPoints * fw.awayRecentW - 0.05 * f.homeAdvantage * fw.homeAdvW;
  const xgRatio = (f.homeXgFor / Math.max(f.awayXgFor, 0.3)) * fw.xgRatioW;
  const t2H = 0.25 + 0.1 * Math.tanh(xgRatio - 1) + 0.1 * f.homePPG * fw.ppgDiffW;
  const t2D = w.drawCalibration - 0.03 * Math.abs(f.homeXgFor - f.awayXgFor);
  const t2A = 0.25 - 0.1 * Math.tanh(xgRatio - 1) + 0.1 * f.awayPPG * fw.ppgDiffW;
  const t3H = 0.2 + 0.15 * f.h2hHomeWinRate * fw.h2hW;
  const t3D = w.drawCalibration + 0.05 * (1 - Math.abs(f.h2hHomeWinRate - 0.5) * 2);
  const t3A = 0.2 + 0.1 * (1 - f.h2hHomeWinRate) * fw.h2hW + 0.05 * f.awayTrend * fw.awayTrendW;
  const gdBoost = Math.tanh(f.homeGoalDiff - f.awayGoalDiff) * 0.1 * fw.gdDiffW;
  const t4H = 0.3 + gdBoost;
  const t4D = w.drawCalibration - Math.abs(gdBoost) * 0.3;
  const t4A = 0.3 - gdBoost;
  const [tw0, tw1, tw2, tw3] = w.treeWeights;
  const rawH = tw0 * t1H + tw1 * t2H + tw2 * t3H + tw3 * t4H;
  const rawD = tw0 * t1D + tw1 * t2D + tw2 * t3D + tw3 * t4D;
  const rawA = tw0 * t1A + tw1 * t2A + tw2 * t3A + tw3 * t4A;
  const adjH = rawH + w.homeAdvBias * f.homeAdvantage;
  const adjD = rawD;
  const adjA = rawA - w.homeAdvBias * f.homeAdvantage * 0.5;
  const expH = Math.exp(adjH * 3);
  const expD = Math.exp(adjD * 3);
  const expA = Math.exp(adjA * 3);
  const sumExp = expH + expD + expA;
  return [expH / sumExp, expD / sumExp, expA / sumExp];
}

function computeLogLoss(probs: [number, number, number], actual: Outcome): number {
  return -Math.log(Math.max(1e-7, probs[actual]));
}

function trainOnExample(f: MLFeatureVector, actual: Outcome, weights: ModelWeights, lr = 0.02): { updatedWeights: ModelWeights; loss: number } {
  const probs = forwardPass(f, weights);
  const loss = computeLogLoss(probs, actual);
  const grad: [number, number, number] = [
    probs[0] - (actual === 0 ? 1 : 0),
    probs[1] - (actual === 1 ? 1 : 0),
    probs[2] - (actual === 2 ? 1 : 0),
  ];
  const fw = weights.featureWeights;
  const newWeights = { ...weights };
  const newFw = { ...fw };
  const newTw: [number, number, number, number] = [...weights.treeWeights] as [number, number, number, number];
  const homeDelta = grad[0] - grad[2];
  newTw[0] = Math.max(0.05, Math.min(0.6, newTw[0] - lr * homeDelta * 0.1));
  newTw[1] = Math.max(0.05, Math.min(0.6, newTw[1] - lr * homeDelta * 0.1));
  newTw[2] = Math.max(0.05, Math.min(0.6, newTw[2] - lr * homeDelta * 0.08));
  newTw[3] = Math.max(0.05, Math.min(0.6, newTw[3] - lr * homeDelta * 0.1));
  const twSum = newTw.reduce((a, b) => a + b, 0);
  newWeights.treeWeights = newTw.map(w => w / twSum) as [number, number, number, number];
  const featGrad = homeDelta * lr * 0.05;
  newFw.homeWinRateW = Math.max(0.3, Math.min(2.0, fw.homeWinRateW - featGrad * f.homeWinRate));
  newFw.awayWinRateW = Math.max(0.3, Math.min(2.0, fw.awayWinRateW + featGrad * f.awayWinRate));
  newFw.homeRecentW = Math.max(0.3, Math.min(2.0, fw.homeRecentW - featGrad * f.homeRecentPoints * 0.5));
  newFw.awayRecentW = Math.max(0.3, Math.min(2.0, fw.awayRecentW + featGrad * f.awayRecentPoints * 0.5));
  newFw.xgRatioW = Math.max(0.3, Math.min(2.0, fw.xgRatioW - featGrad * 0.5));
  newFw.h2hW = Math.max(0.3, Math.min(2.0, fw.h2hW - featGrad * f.h2hHomeWinRate * 0.3));
  newFw.homeAdvW = Math.max(0.3, Math.min(2.0, fw.homeAdvW - featGrad * f.homeAdvantage * 0.4));
  newFw.gdDiffW = Math.max(0.3, Math.min(2.0, fw.gdDiffW - featGrad * (f.homeGoalDiff - f.awayGoalDiff) * 0.2));
  newWeights.homeAdvBias = Math.max(0.0, Math.min(0.15, weights.homeAdvBias - lr * grad[0] * f.homeAdvantage * 0.1));
  newWeights.drawCalibration = Math.max(0.15, Math.min(0.35, weights.drawCalibration - lr * grad[1] * 0.1));
  newWeights.featureWeights = newFw;
  return { updatedWeights: newWeights, loss };
}

function computeAccuracy(records: TrainingRecord[]): number {
  if (!records.length) return 0;
  let correct = 0;
  for (const r of records) {
    if (r.actualOutcome === undefined) continue;
    const predicted = r.predictedProbs.indexOf(Math.max(...r.predictedProbs)) as Outcome;
    if (predicted === r.actualOutcome) correct++;
  }
  return Math.round((correct / records.length) * 100);
}

let isTraining = false;

async function fetchMatchResult(matchId: number): Promise<{ homeGoals: number; awayGoals: number; finished: boolean } | null> {
  try {
    const url = new URL(`https://api.sstats.net/games/${matchId}`);
    url.searchParams.set('apikey', 'gbi1ldi9446kastj');
    const res = await fetch(url.toString(), { headers: { 'User-Agent': 'SStats-Mobile-App/1.0', Accept: 'application/json' } });
    if (!res.ok) return null;
    const data = await res.json() as Record<string, unknown>;
    const inner = data.data as Record<string, unknown> | undefined;
    const game = (inner?.game || inner || data) as Record<string, unknown>;
    const statusName = String(game.statusName || '').toLowerCase();
    const FINISHED = new Set(['finished', 'ft', 'full time', 'ended', 'aet', 'pen', 'finished after extra time', 'finished after penalty']);
    const finished = FINISHED.has(statusName) || Number(game.status) === 8 || Number(game.status) === 9 || Number(game.status) === 10;
    if (!finished) return null;
    const homeGoals = game.homeResult as number;
    const awayGoals = game.awayResult as number;
    if (homeGoals === null || homeGoals === undefined || awayGoals === null || awayGoals === undefined) return null;
    return { homeGoals, awayGoals, finished: true };
  } catch {
    return null;
  }
}

async function runTrainingCycle() {
  if (isTraining) return;
  isTraining = true;
  try {
    const now = new Date();
    const pending = state.pendingPredictions.filter(p => !p.actualOutcome);
    if (pending.length === 0) { console.log('[ML] No pending predictions to check'); return; }
    console.log(`[ML] Checking ${pending.length} pending predictions for results...`);
    let trainedCount = 0;
    let updatedWeights = { ...state.weights };
    const newLosses: number[] = [];
    const eligibleRecords = pending.filter(p => {
      const matchDate = new Date(p.matchDate);
      return (now.getTime() - matchDate.getTime()) > 2 * 60 * 60 * 1000;
    });
    for (const record of eligibleRecords) {
      const result = await fetchMatchResult(record.matchId);
      if (!result) continue;
      let actualOutcome: Outcome;
      if (result.homeGoals > result.awayGoals) actualOutcome = 0;
      else if (result.homeGoals < result.awayGoals) actualOutcome = 2;
      else actualOutcome = 1;
      record.actualOutcome = actualOutcome;
      record.homeGoals = result.homeGoals;
      record.awayGoals = result.awayGoals;
      record.trainedAt = new Date().toISOString();
      const { updatedWeights: newW, loss } = trainOnExample(record.features, actualOutcome, updatedWeights);
      updatedWeights = newW;
      newLosses.push(loss);
      trainedCount++;
    }
    if (trainedCount > 0) {
      state.weights = updatedWeights;
      state.weights.totalMatchesTrained += trainedCount;
      state.weights.lastTrainedAt = new Date().toISOString();
      state.weights.version++;
      state.weights.lossHistory = [...state.weights.lossHistory, ...newLosses].slice(-50);
      const sevenDaysAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
      const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
      const recent7 = state.completedRecords.filter(r => r.trainedAt && new Date(r.trainedAt) > sevenDaysAgo && r.actualOutcome !== undefined);
      const recent30 = state.completedRecords.filter(r => r.trainedAt && new Date(r.trainedAt) > thirtyDaysAgo && r.actualOutcome !== undefined);
      state.weights.accuracy7day = computeAccuracy(recent7);
      state.weights.accuracy30day = computeAccuracy(recent30);
      const trainedIds = new Set(eligibleRecords.filter(r => r.actualOutcome !== undefined).map(r => r.matchId));
      state.pendingPredictions = state.pendingPredictions.filter(p => !trainedIds.has(p.matchId));
      state.completedRecords.push(...eligibleRecords.filter(r => r.actualOutcome !== undefined));
      saveState(state);
      console.log(`[ML] Trained on ${trainedCount} matches. Version: ${state.weights.version}`);
    }
  } finally {
    isTraining = false;
  }
}

export function startTrainingScheduler() {
  console.log('[ML] Starting training scheduler...');
  setTimeout(() => runTrainingCycle().catch(console.error), 30 * 1000);
  setInterval(() => runTrainingCycle().catch(console.error), 60 * 60 * 1000);
}

export function predict(features: MLFeatureVector): [number, number, number] {
  return forwardPass(features, state.weights);
}

export function savePrediction(
  matchId: number, matchDate: string, homeTeam: string, awayTeam: string,
  features: MLFeatureVector, predictedProbs: [number, number, number]
) {
  const exists = state.pendingPredictions.find(p => p.matchId === matchId);
  if (!exists) {
    state.pendingPredictions.push({ matchId, matchDate, homeTeam, awayTeam, features, predictedProbs });
    if (state.pendingPredictions.length % 10 === 0) saveState(state);
  }
}

export function getModelStats() {
  return {
    totalMatchesTrained: state.weights.totalMatchesTrained,
    accuracy7day: state.weights.accuracy7day,
    accuracy30day: state.weights.accuracy30day,
    pendingPredictions: state.pendingPredictions.filter(p => !p.actualOutcome).length,
    modelVersion: state.weights.version,
    lastTrainedAt: state.weights.lastTrainedAt,
    lossHistory: state.weights.lossHistory.slice(-10),
  };
}

export async function triggerTraining() {
  await runTrainingCycle();
  return getModelStats();
}

export interface HistoryTrainingEntry {
  matchId: number | string;
  homeTeam: string;
  awayTeam: string;
  homeResult: number;
  awayResult: number;
  homeWinPct: number;
  drawPct: number;
  awayWinPct: number;
}

export function trainFromHistory(entries: HistoryTrainingEntry[]): { trained: number } {
  let trained = 0;
  for (const entry of entries) {
    const matchId = Number(entry.matchId);
    if (isNaN(matchId)) continue;
    const alreadyTrained = state.completedRecords.some(r => r.matchId === matchId);
    if (alreadyTrained) continue;
    const homeGoals = entry.homeResult;
    const awayGoals = entry.awayResult;
    let actualOutcome: 0 | 1 | 2;
    if (homeGoals > awayGoals) actualOutcome = 0;
    else if (homeGoals === awayGoals) actualOutcome = 1;
    else actualOutcome = 2;
    const predictedProbs: [number, number, number] = [
      entry.homeWinPct / 100,
      entry.drawPct / 100,
      entry.awayWinPct / 100,
    ];
    const features: MLFeatureVector = {
      homeWinRate: entry.homeWinPct / 100,
      awayWinRate: entry.awayWinPct / 100,
      homeAvgGoalsFor: homeGoals,
      awayAvgGoalsFor: awayGoals,
      homeAvgGoalsAgainst: awayGoals,
      awayAvgGoalsAgainst: homeGoals,
      homeRecentPoints: entry.homeWinPct / 100,
      awayRecentPoints: entry.awayWinPct / 100,
      homeTrend: 0.5,
      awayTrend: 0.5,
      homeXgFor: homeGoals,
      awayXgFor: awayGoals,
      h2hHomeWinRate: 0.35,
      h2hAvgGoals: homeGoals + awayGoals,
      homeAdvantage: 0.5,
      homePPG: 0.5,
      awayPPG: 0.5,
      homeGoalDiff: homeGoals - awayGoals,
      awayGoalDiff: awayGoals - homeGoals,
      formDiff: (entry.homeWinPct - entry.awayWinPct) / 100,
    };
    const existingPending = state.pendingPredictions.find(p => p.matchId === matchId);
    const record: TrainingRecord = {
      matchId,
      matchDate: new Date().toISOString(),
      features: existingPending?.features || features,
      predictedProbs: existingPending?.predictedProbs || predictedProbs,
      homeTeam: entry.homeTeam,
      awayTeam: entry.awayTeam,
      actualOutcome,
      homeGoals,
      awayGoals,
      trainedAt: new Date().toISOString(),
    };
    const { updatedWeights, loss } = trainOnExample(record.features, actualOutcome, state.weights, 0.01);
    state.weights = updatedWeights;
    state.weights.totalMatchesTrained++;
    state.weights.lossHistory.push(loss);
    state.completedRecords.push(record);
    state.pendingPredictions = state.pendingPredictions.filter(p => p.matchId !== matchId);
    trained++;
  }
  if (trained > 0) {
    state.weights.version++;
    state.weights.lastTrainedAt = new Date().toISOString();
    const sevenDaysAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
    const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
    const recent7 = state.completedRecords.filter(r => r.trainedAt && new Date(r.trainedAt) > sevenDaysAgo);
    const recent30 = state.completedRecords.filter(r => r.trainedAt && new Date(r.trainedAt) > thirtyDaysAgo);
    state.weights.accuracy7day = computeAccuracy(recent7);
    state.weights.accuracy30day = computeAccuracy(recent30);
    saveState(state);
    console.log(`[ML] Trained from history: ${trained} matches. Version: ${state.weights.version}`);
  }
  return { trained };
}
