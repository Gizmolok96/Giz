import React, { useEffect, useRef, useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, Pressable,
  ActivityIndicator, Animated, Platform,
} from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { Ionicons, Feather, MaterialCommunityIcons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useQuery } from '@tanstack/react-query';
import { getApiUrl } from '../lib/api';
import { Colors } from '../constants/colors';
import { saveToHistory, syncHistoryToModel } from './(tabs)/history';

interface TeamStat {
  result: 'W' | 'D' | 'L'; is_home: boolean;
  date: string; opponent: string;
  xg_for?: number | null; xg_against?: number | null;
  possession?: number; shots?: number; shots_on_target?: number;
  goals_for?: number; goals_against?: number;
}

interface MLPrediction {
  homeWinProb: number; drawProb: number; awayWinProb: number;
  confidence: number; modelUsed: string;
  features: { homeForm: number; awayForm: number; h2hAdvantage: number; homeAdvantage: number };
  available: boolean;
  trainingStats?: { totalMatchesTrained: number; accuracy7day: number; accuracy30day: number; pendingPredictions: number; modelVersion: number };
}

interface H2HMatch {
  date?: string;
  homeTeam?: { name?: string };
  awayTeam?: { name?: string };
  homeResult?: number;
  awayResult?: number;
}

interface TeamFeatures {
  pointsPerGame: number; winRate: number; drawRate: number; lossRate: number;
  avgGoalsFor: number; avgGoalsAgainst: number; xgForAvg: number; xgAgainstAvg: number;
  avgPossession: number; avgShots: number; avgShotsOnTarget: number;
  recentPoints: number; trend: number; homeAdvantage: number;
  totalMatches: number; formString: string;
}

interface Analysis {
  homeXg: number; awayXg: number;
  homeWinPct: number; drawPct: number; awayWinPct: number;
  mostLikelyScore: string; mostLikelyProb: number;
  over25Pct: number; bttsPct: number; expectedTotal: number;
  homeFeatures: TeamFeatures; awayFeatures: TeamFeatures;
  h2h: { homeWins: number; draws: number; awayWins: number; total: number; avgGoals: number; matches: H2HMatch[] };
  bettingTips: { market: string; confidence: string; reason: string }[];
  keyFactors: string[];
  confidenceScore: number;
  leagueContext: { avgGoals: number; style: string };
  mlPrediction?: MLPrediction;
}

interface MatchData {
  id?: number | string;
  homeTeam?: { name?: string; id?: number };
  awayTeam?: { name?: string; id?: number };
  homeResult?: number | null; awayResult?: number | null;
  statusName?: string; date?: string; league?: string;
}

interface AnalysisResponse {
  match: MatchData;
  analysis: Analysis;
  homeRecentMatches: TeamStat[];
  awayRecentMatches: TeamStat[];
}

function AnimatedBar({ pct, color, delay }: { pct: number; color: string; delay: number }) {
  const anim = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    Animated.timing(anim, { toValue: pct, duration: 700, delay, useNativeDriver: false }).start();
  }, [pct, delay]);
  return (
    <View style={aStyles.barTrack}>
      <Animated.View style={[aStyles.barFill, { backgroundColor: color, width: anim.interpolate({ inputRange: [0, 100], outputRange: ['0%', '100%'] }) }]} />
    </View>
  );
}

function FormBadge({ result }: { result: 'W' | 'D' | 'L' }) {
  const colors: Record<string, string> = { W: Colors.win, D: Colors.draw, L: Colors.loss };
  return (
    <View style={[fStyles.badge, { backgroundColor: colors[result] + '33' }]}>
      <Text style={[fStyles.badgeText, { color: colors[result] }]}>{result}</Text>
    </View>
  );
}

function TeamFormRow({ name, stats, isHome }: { name: string; stats: TeamStat[]; isHome: boolean }) {
  const recent = stats.slice(0, 5);
  return (
    <View style={fStyles.teamFormRow}>
      <View style={[fStyles.teamDot, { backgroundColor: isHome ? Colors.home : Colors.away }]} />
      <Text style={fStyles.teamLabel} numberOfLines={1}>{name}</Text>
      <View style={fStyles.badgeRow}>
        {recent.map((s, i) => <FormBadge key={i} result={s.result} />)}
        {Array.from({ length: Math.max(0, 5 - recent.length) }).map((_, i) => (
          <View key={`empty-${i}`} style={[fStyles.badge, { backgroundColor: Colors.border }]}>
            <Text style={[fStyles.badgeText, { color: Colors.textMuted }]}>?</Text>
          </View>
        ))}
      </View>
    </View>
  );
}

function StatCompare({ label, homeVal, awayVal, format }: { label: string; homeVal: number; awayVal: number; format: (v: number) => string }) {
  const total = homeVal + awayVal || 1;
  const homePct = (homeVal / total) * 100;
  const awayPct = (awayVal / total) * 100;
  return (
    <View style={sStyles.row}>
      <Text style={sStyles.val}>{format(homeVal)}</Text>
      <View style={sStyles.bars}>
        <Text style={sStyles.label}>{label}</Text>
        <View style={sStyles.barRow}>
          <View style={[sStyles.homeBar, { width: `${homePct}%` as any }]} />
          <View style={[sStyles.awayBar, { width: `${awayPct}%` as any }]} />
        </View>
      </View>
      <Text style={[sStyles.val, { textAlign: 'right' }]}>{format(awayVal)}</Text>
    </View>
  );
}

function SectionCard({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <View style={styles.card}>
      <Text style={styles.cardTitle}>{title}</Text>
      {children}
    </View>
  );
}

async function fetchAnalysis(id: string): Promise<AnalysisResponse> {
  const apiUrl = getApiUrl();
  const res = await fetch(`${apiUrl}/api/match/${id}/analyze`);
  if (!res.ok) throw new Error(`Analysis failed: ${res.status}`);
  return res.json();
}

function getInitials(name?: string): string {
  if (!name) return '?';
  const parts = name.trim().split(/\s+/);
  if (parts.length === 1) return parts[0].substring(0, 3).toUpperCase();
  return parts.slice(0, 2).map((p) => p[0]).join('').toUpperCase();
}

function confidenceColor(score: number): string {
  if (score >= 70) return Colors.accent;
  if (score >= 50) return Colors.amber;
  return Colors.red;
}

function pctColor(pct: number): string {
  if (pct >= 65) return Colors.purple;
  if (pct >= 35) return Colors.amber;
  return Colors.textMuted;
}

function tipConfidenceColor(conf: string): string {
  const c = conf.toLowerCase();
  if (c === 'high') return Colors.purple;
  if (c === 'medium') return Colors.amber;
  return Colors.textMuted;
}

function tipConfidenceBg(conf: string): string {
  const c = conf.toLowerCase();
  if (c === 'high') return Colors.purpleDim;
  if (c === 'medium') return Colors.amberDim;
  return Colors.bgCardDark;
}

function tipIcon(market: string): string {
  const m = market.toLowerCase();
  if (m.includes('over') || m.includes('goal') || m.includes('total')) return 'soccer';
  if (m.includes('both') || m.includes('btts')) return 'target';
  if (m.includes('home') || m.includes('win')) return 'home';
  if (m.includes('draw')) return 'equal';
  if (m.includes('away')) return 'airplane';
  if (m.includes('corner')) return 'flag';
  if (m.includes('card')) return 'card-outline';
  return 'chart-bar';
}

export default function AnalysisScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const insets = useSafeAreaInsets();
  const [activeTab, setActiveTab] = useState<'overview' | 'form' | 'h2h' | 'ml'>('overview');

  const { data, isLoading, isError, error, refetch } = useQuery({
    queryKey: ['analysis', id],
    queryFn: () => fetchAnalysis(id!),
    enabled: !!id,
    staleTime: 5 * 60 * 1000,
  });

  useEffect(() => {
    if (data) {
      const { match, analysis } = data;
      const isFinishedMatch =
        match.homeResult !== null && match.homeResult !== undefined &&
        match.awayResult !== null && match.awayResult !== undefined;
      saveToHistory({
        matchId: match.id ?? id ?? 'unknown',
        homeTeam: match.homeTeam?.name ?? 'Unknown',
        awayTeam: match.awayTeam?.name ?? 'Unknown',
        homeResult: match.homeResult,
        awayResult: match.awayResult,
        statusName: match.statusName,
        league: match.league,
        homeWinPct: analysis.homeWinPct,
        drawPct: analysis.drawPct,
        awayWinPct: analysis.awayWinPct,
        confidenceScore: analysis.confidenceScore,
        mostLikelyScore: analysis.mostLikelyScore,
        mlModelVersion: analysis.mlPrediction?.trainingStats?.modelVersion,
      }).then(() => {
        if (isFinishedMatch) {
          syncHistoryToModel(getApiUrl()).catch(() => {});
        }
      });
    }
  }, [data, id]);

  const topPad = insets.top + (Platform.OS === 'web' ? 67 : 0);
  const bottomPad = insets.bottom + (Platform.OS === 'web' ? 34 : 0);

  if (isLoading) {
    return (
      <View style={[styles.container, { paddingTop: topPad }]}>
        <View style={styles.header}>
          <Pressable style={styles.backBtn} onPress={() => router.back()}>
            <Ionicons name="chevron-back" size={22} color={Colors.text} />
          </Pressable>
        </View>
        <View style={styles.loadingState}>
          <ActivityIndicator size="large" color={Colors.accent} />
          <Text style={styles.loadingTitle}>Analyzing match...</Text>
          <Text style={styles.loadingSubtitle}>Crunching stats & ML predictions</Text>
        </View>
      </View>
    );
  }

  if (isError || !data) {
    return (
      <View style={[styles.container, { paddingTop: topPad }]}>
        <View style={styles.header}>
          <Pressable style={styles.backBtn} onPress={() => router.back()}>
            <Ionicons name="chevron-back" size={22} color={Colors.text} />
          </Pressable>
        </View>
        <View style={styles.errorState}>
          <MaterialCommunityIcons name="wifi-off" size={48} color={Colors.textMuted} />
          <Text style={styles.errorTitle}>Analysis failed</Text>
          <Text style={styles.errorSubtitle}>{error instanceof Error ? error.message : 'Unknown error'}</Text>
          <Pressable style={styles.retryBtn} onPress={() => refetch()}>
            <Text style={styles.retryText}>Try Again</Text>
          </Pressable>
        </View>
      </View>
    );
  }

  const { match, analysis, homeRecentMatches, awayRecentMatches } = data;
  const ml = analysis.mlPrediction;
  const homeInitials = getInitials(match.homeTeam?.name);
  const awayInitials = getInitials(match.awayTeam?.name);
  const isFinished = match.homeResult !== null && match.homeResult !== undefined && match.awayResult !== null && match.awayResult !== undefined;
  const confColor = confidenceColor(analysis.confidenceScore);

  return (
    <View style={[styles.container, { paddingTop: topPad }]}>
      <View style={styles.header}>
        <Pressable style={styles.backBtn} onPress={() => router.back()}>
          <Ionicons name="chevron-back" size={22} color={Colors.text} />
        </Pressable>
        <Text style={styles.headerLeague} numberOfLines={1}>{match.league || 'Match Analysis'}</Text>
        <View style={styles.confBadge}>
          <Text style={[styles.confPct, { color: confColor }]}>{analysis.confidenceScore.toFixed(0)}%</Text>
        </View>
      </View>

      <View style={styles.matchHero}>
        <View style={styles.teamBlock}>
          <View style={styles.teamAvatar}>
            <Text style={styles.teamAvatarText}>{homeInitials}</Text>
          </View>
          <Text style={styles.teamName} numberOfLines={2}>{match.homeTeam?.name || 'Home'}</Text>
        </View>

        <View style={styles.scoreBlock}>
          {isFinished ? (
            <>
              <Text style={styles.scoreText}>{match.homeResult} : {match.awayResult}</Text>
              <Text style={styles.scoreLabel}>FINAL</Text>
            </>
          ) : (
            <>
              <Text style={styles.predictedScore}>{analysis.mostLikelyScore}</Text>
              <Text style={styles.scoreLabel}>PREDICTED</Text>
              <Text style={styles.scoreProbText}>{(analysis.mostLikelyProb * 100).toFixed(0)}% likely</Text>
            </>
          )}
        </View>

        <View style={[styles.teamBlock, { alignItems: 'flex-end' }]}>
          <View style={[styles.teamAvatar, { backgroundColor: Colors.purpleDim }]}>
            <Text style={styles.teamAvatarText}>{awayInitials}</Text>
          </View>
          <Text style={[styles.teamName, { textAlign: 'right' }]} numberOfLines={2}>{match.awayTeam?.name || 'Away'}</Text>
        </View>
      </View>

      <View style={styles.probRow}>
        <View style={styles.probItem}>
          <Text style={[styles.probPct, { color: pctColor(analysis.homeWinPct) }]}>{analysis.homeWinPct.toFixed(0)}%</Text>
          <AnimatedBar pct={analysis.homeWinPct} color={pctColor(analysis.homeWinPct)} delay={0} />
          <Text style={styles.probLabel}>Home</Text>
        </View>
        <View style={styles.probItem}>
          <Text style={[styles.probPct, { color: pctColor(analysis.drawPct) }]}>{analysis.drawPct.toFixed(0)}%</Text>
          <AnimatedBar pct={analysis.drawPct} color={pctColor(analysis.drawPct)} delay={100} />
          <Text style={styles.probLabel}>Draw</Text>
        </View>
        <View style={styles.probItem}>
          <Text style={[styles.probPct, { color: pctColor(analysis.awayWinPct) }]}>{analysis.awayWinPct.toFixed(0)}%</Text>
          <AnimatedBar pct={analysis.awayWinPct} color={pctColor(analysis.awayWinPct)} delay={200} />
          <Text style={styles.probLabel}>Away</Text>
        </View>
      </View>

      <View style={styles.tabBar}>
        {(['overview', 'form', 'h2h', 'ml'] as const).map((t) => (
          <Pressable
            key={t}
            style={[styles.tab, activeTab === t && styles.tabActive]}
            onPress={() => setActiveTab(t)}
          >
            <Text style={[styles.tabText, activeTab === t && styles.tabTextActive]}>
              {t === 'overview' ? 'Overview' : t === 'form' ? 'Form' : t === 'h2h' ? 'H2H' : 'ML'}
            </Text>
          </Pressable>
        ))}
      </View>

      <ScrollView
        contentContainerStyle={[styles.scrollContent, { paddingBottom: bottomPad + 20 }]}
        showsVerticalScrollIndicator={false}
      >
        {activeTab === 'overview' && (
          <>
            <SectionCard title="Key Stats">
              <StatCompare label="xG" homeVal={analysis.homeXg} awayVal={analysis.awayXg} format={(v) => v.toFixed(2)} />
              <StatCompare label="Win Rate" homeVal={analysis.homeFeatures?.winRate ?? 0} awayVal={analysis.awayFeatures?.winRate ?? 0} format={(v) => `${(v * 100).toFixed(0)}%`} />
              <StatCompare label="Avg Goals" homeVal={analysis.homeFeatures?.avgGoalsFor ?? 0} awayVal={analysis.awayFeatures?.avgGoalsFor ?? 0} format={(v) => v.toFixed(1)} />
              <StatCompare label="Possession" homeVal={analysis.homeFeatures?.avgPossession ?? 50} awayVal={analysis.awayFeatures?.avgPossession ?? 50} format={(v) => `${v.toFixed(0)}%`} />
            </SectionCard>

            <SectionCard title="Market Signals">
              <View style={styles.marketRow}>
                <View style={[styles.marketItem, { flex: 1, borderRightWidth: 1, borderRightColor: Colors.border }]}>
                  <Text style={[styles.marketValue, { color: pctColor(analysis.over25Pct) }]}>{analysis.over25Pct.toFixed(0)}%</Text>
                  <Text style={styles.marketLabel}>Over 2.5 Goals</Text>
                </View>
                <View style={[styles.marketItem, { flex: 1 }]}>
                  <Text style={[styles.marketValue, { color: pctColor(analysis.bttsPct) }]}>{analysis.bttsPct.toFixed(0)}%</Text>
                  <Text style={styles.marketLabel}>Both Teams Score</Text>
                </View>
              </View>
              <View style={[styles.marketItem, { borderTopWidth: 1, borderTopColor: Colors.border, paddingTop: 10 }]}>
                <Text style={[styles.marketValue, { color: Colors.text }]}>{analysis.expectedTotal.toFixed(2)}</Text>
                <Text style={styles.marketLabel}>Expected Total Goals</Text>
              </View>
            </SectionCard>

            {analysis.keyFactors?.length > 0 && (
              <SectionCard title="Key Factors">
                {analysis.keyFactors.map((f, i) => (
                  <View key={i} style={styles.factorRow}>
                    <MaterialCommunityIcons name="check-circle" size={14} color={Colors.accent} />
                    <Text style={styles.factorText}>{f}</Text>
                  </View>
                ))}
              </SectionCard>
            )}

            {analysis.bettingTips?.length > 0 && (
              <View style={styles.tipsContainer}>
                <Text style={styles.tipsTitle}>Tips</Text>
                {analysis.bettingTips.map((tip, i) => {
                  const confColor = tipConfidenceColor(tip.confidence);
                  const confBg = tipConfidenceBg(tip.confidence);
                  const icon = tipIcon(tip.market);
                  return (
                    <View key={i} style={[styles.tipCard, { borderLeftColor: confColor, backgroundColor: confBg + '33' }]}>
                      <View style={[styles.tipIconBox, { backgroundColor: confBg }]}>
                        <MaterialCommunityIcons name={icon as any} size={18} color={confColor} />
                      </View>
                      <View style={styles.tipBody}>
                        <View style={styles.tipHeaderRow}>
                          <Text style={[styles.tipMarket, { color: confColor }]} numberOfLines={1}>{tip.market}</Text>
                          <View style={[styles.tipBadge, { backgroundColor: confBg, borderColor: confColor + '88' }]}>
                            <View style={[styles.tipBadgeDot, { backgroundColor: confColor }]} />
                            <Text style={[styles.tipConf, { color: confColor }]}>{tip.confidence}</Text>
                          </View>
                        </View>
                        <Text style={styles.tipReason}>{tip.reason}</Text>
                      </View>
                    </View>
                  );
                })}
              </View>
            )}
          </>
        )}

        {activeTab === 'form' && (
          <>
            <SectionCard title="Recent Form (Last 5)">
              <TeamFormRow name={match.homeTeam?.name ?? 'Home'} stats={homeRecentMatches} isHome={true} />
              <View style={{ height: 10 }} />
              <TeamFormRow name={match.awayTeam?.name ?? 'Away'} stats={awayRecentMatches} isHome={false} />
            </SectionCard>

            <SectionCard title="Home Team Recent Matches">
              {homeRecentMatches.length === 0 ? (
                <Text style={styles.noDataText}>No recent data</Text>
              ) : (
                homeRecentMatches.slice(0, 5).map((s, i) => (
                  <View key={i} style={styles.recentMatch}>
                    <View style={[styles.resultDot, { backgroundColor: s.result === 'W' ? Colors.win : s.result === 'D' ? Colors.draw : Colors.loss }]} />
                    <Text style={styles.recentOpponent} numberOfLines={1}>{s.is_home ? 'vs' : '@'} {s.opponent}</Text>
                    <Text style={styles.recentScore}>{s.goals_for ?? '?'} - {s.goals_against ?? '?'}</Text>
                    <Text style={styles.recentDate}>{s.date ? s.date.split('T')[0] : ''}</Text>
                  </View>
                ))
              )}
            </SectionCard>

            <SectionCard title="Away Team Recent Matches">
              {awayRecentMatches.length === 0 ? (
                <Text style={styles.noDataText}>No recent data</Text>
              ) : (
                awayRecentMatches.slice(0, 5).map((s, i) => (
                  <View key={i} style={styles.recentMatch}>
                    <View style={[styles.resultDot, { backgroundColor: s.result === 'W' ? Colors.win : s.result === 'D' ? Colors.draw : Colors.loss }]} />
                    <Text style={styles.recentOpponent} numberOfLines={1}>{s.is_home ? 'vs' : '@'} {s.opponent}</Text>
                    <Text style={styles.recentScore}>{s.goals_for ?? '?'} - {s.goals_against ?? '?'}</Text>
                    <Text style={styles.recentDate}>{s.date ? s.date.split('T')[0] : ''}</Text>
                  </View>
                ))
              )}
            </SectionCard>
          </>
        )}

        {activeTab === 'h2h' && (
          <SectionCard title="Head to Head">
            {analysis.h2h.total === 0 ? (
              <Text style={styles.noDataText}>No H2H data available</Text>
            ) : (
              <>
                <View style={styles.h2hSummaryRow}>
                  <View style={styles.h2hItem}>
                    <Text style={[styles.h2hCount, { color: Colors.home }]}>{analysis.h2h.homeWins}</Text>
                    <Text style={styles.h2hLabel}>{match.homeTeam?.name ?? 'Home'} Wins</Text>
                  </View>
                  <View style={styles.h2hItem}>
                    <Text style={[styles.h2hCount, { color: Colors.amber }]}>{analysis.h2h.draws}</Text>
                    <Text style={styles.h2hLabel}>Draws</Text>
                  </View>
                  <View style={styles.h2hItem}>
                    <Text style={[styles.h2hCount, { color: Colors.away }]}>{analysis.h2h.awayWins}</Text>
                    <Text style={styles.h2hLabel}>{match.awayTeam?.name ?? 'Away'} Wins</Text>
                  </View>
                </View>

                <View style={styles.h2hBar}>
                  <View style={[styles.h2hBarHome, { flex: analysis.h2h.homeWins || 0.01 }]} />
                  <View style={[styles.h2hBarDraw, { flex: analysis.h2h.draws || 0.01 }]} />
                  <View style={[styles.h2hBarAway, { flex: analysis.h2h.awayWins || 0.01 }]} />
                </View>

                <View style={styles.h2hAvgRow}>
                  <MaterialCommunityIcons name="soccer" size={12} color={Colors.textMuted} />
                  <Text style={styles.h2hAvgText}>Avg {analysis.h2h.avgGoals.toFixed(1)} goals per match</Text>
                </View>

                {analysis.h2h.matches.slice(0, 5).map((m, i) => (
                  <View key={i} style={styles.h2hMatch}>
                    <Text style={styles.h2hMatchDate}>{m.date ? m.date.split('T')[0] : 'Unknown'}</Text>
                    <View style={styles.h2hMatchTeams}>
                      <Text style={styles.h2hMatchTeam} numberOfLines={1}>{m.homeTeam?.name}</Text>
                      <Text style={styles.h2hMatchScore}>{m.homeResult ?? '?'} - {m.awayResult ?? '?'}</Text>
                      <Text style={[styles.h2hMatchTeam, { textAlign: 'right' }]} numberOfLines={1}>{m.awayTeam?.name}</Text>
                    </View>
                  </View>
                ))}
              </>
            )}
          </SectionCard>
        )}

        {activeTab === 'ml' && (
          <>
            {ml && ml.available ? (
              <SectionCard title="ML Model Prediction">
                <Text style={styles.mlIntroText}>Prediction from adaptive machine learning model trained on historical match outcomes.</Text>

                <View style={[styles.compRow]}>
                  <Text style={styles.compLabel}>Model</Text>
                  <Text style={[styles.compHome, { flex: 3, color: Colors.accent }]}>{ml.modelUsed}</Text>
                </View>

                <View style={[styles.compRow, styles.compDataRow]}>
                  <Text style={styles.compLabel}>Outcome</Text>
                  <Text style={styles.compHome}>Home</Text>
                  <Text style={styles.compDraw}>Draw</Text>
                  <Text style={styles.compAway}>Away</Text>
                </View>
                <View style={[styles.compRow, styles.compDataRow]}>
                  <Text style={styles.compLabel}>Statistical</Text>
                  <Text style={[styles.compHome, { color: Colors.home }]}>{analysis.homeWinPct.toFixed(0)}%</Text>
                  <Text style={[styles.compDraw, { color: Colors.amber }]}>{analysis.drawPct.toFixed(0)}%</Text>
                  <Text style={[styles.compAway, { color: Colors.away }]}>{analysis.awayWinPct.toFixed(0)}%</Text>
                </View>
                <View style={[styles.compRow, styles.compDataRow]}>
                  <Text style={styles.compLabel}>ML Model</Text>
                  <Text style={[styles.compHome, { color: Colors.home }]}>{(ml.homeWinProb * 100).toFixed(0)}%</Text>
                  <Text style={[styles.compDraw, { color: Colors.amber }]}>{(ml.drawProb * 100).toFixed(0)}%</Text>
                  <Text style={[styles.compAway, { color: Colors.away }]}>{(ml.awayWinProb * 100).toFixed(0)}%</Text>
                </View>

                <Text style={styles.mlNote}>
                  ML confidence: {(ml.confidence * 100).toFixed(0)}%. The model adjusts weights based on real match results over time.
                </Text>
              </SectionCard>
            ) : (
              <SectionCard title="ML Model">
                <Text style={styles.mlIntroText}>The ML model is warming up. Analyze more matches to train it on real outcomes.</Text>
              </SectionCard>
            )}

            {ml?.trainingStats && (
              <SectionCard title="Model Training Stats">
                <View style={styles.trainingGrid}>
                  <View style={styles.trainingCard}>
                    <Text style={styles.trainingValue}>{ml.trainingStats.totalMatchesTrained}</Text>
                    <Text style={styles.trainingLabel}>Matches trained</Text>
                  </View>
                  <View style={styles.trainingCard}>
                    <Text style={styles.trainingValue}>{(ml.trainingStats.accuracy7day * 100).toFixed(0)}%</Text>
                    <Text style={styles.trainingLabel}>7-day accuracy</Text>
                  </View>
                  <View style={styles.trainingCard}>
                    <Text style={styles.trainingValue}>{(ml.trainingStats.accuracy30day * 100).toFixed(0)}%</Text>
                    <Text style={styles.trainingLabel}>30-day accuracy</Text>
                  </View>
                  <View style={styles.trainingCard}>
                    <Text style={styles.trainingValue}>v{ml.trainingStats.modelVersion}</Text>
                    <Text style={styles.trainingLabel}>Model version</Text>
                  </View>
                </View>
                <View style={styles.howRow}>
                  <View style={styles.howStep}><Text style={styles.howNum}>1</Text></View>
                  <Text style={styles.howText}>Analyze matches before they happen to get predictions</Text>
                </View>
                <View style={styles.howRow}>
                  <View style={styles.howStep}><Text style={styles.howNum}>2</Text></View>
                  <Text style={styles.howText}>Come back after the match — the model learns from the real result</Text>
                </View>
                <View style={styles.howRow}>
                  <View style={styles.howStep}><Text style={styles.howNum}>3</Text></View>
                  <Text style={styles.howText}>Accuracy improves over time as more matches are analyzed</Text>
                </View>
              </SectionCard>
            )}
          </>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg },
  header: {
    flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingVertical: 10, gap: 10,
  },
  backBtn: { width: 36, height: 36, borderRadius: 10, backgroundColor: Colors.bgCard, alignItems: 'center', justifyContent: 'center' },
  headerLeague: { flex: 1, fontFamily: 'Inter_600SemiBold', fontSize: 15, color: Colors.textSecondary },
  confBadge: { backgroundColor: Colors.bgCard, paddingHorizontal: 10, paddingVertical: 4, borderRadius: 8 },
  confPct: { fontFamily: 'Inter_700Bold', fontSize: 14 },
  matchHero: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingVertical: 12, gap: 8 },
  teamBlock: { flex: 1, alignItems: 'flex-start', gap: 8 },
  teamAvatar: { width: 52, height: 52, borderRadius: 14, backgroundColor: Colors.blueDim, alignItems: 'center', justifyContent: 'center' },
  teamAvatarText: { fontFamily: 'Inter_700Bold', fontSize: 14, color: Colors.text },
  teamName: { fontFamily: 'Inter_500Medium', fontSize: 13, color: Colors.text, lineHeight: 18 },
  scoreBlock: { alignItems: 'center', gap: 2, minWidth: 80 },
  scoreText: { fontFamily: 'Inter_700Bold', fontSize: 28, color: Colors.text },
  predictedScore: { fontFamily: 'Inter_700Bold', fontSize: 26, color: Colors.textSecondary },
  scoreLabel: { fontFamily: 'Inter_400Regular', fontSize: 10, color: Colors.textMuted, letterSpacing: 1 },
  scoreProbText: { fontFamily: 'Inter_500Medium', fontSize: 11, color: Colors.accent },
  probRow: { flexDirection: 'row', paddingHorizontal: 16, paddingVertical: 12, gap: 12 },
  probItem: { flex: 1, gap: 4 },
  probPct: { fontFamily: 'Inter_700Bold', fontSize: 18, textAlign: 'center' },
  probLabel: { fontFamily: 'Inter_400Regular', fontSize: 11, color: Colors.textMuted, textAlign: 'center' },
  tabBar: { flexDirection: 'row', paddingHorizontal: 12, paddingVertical: 6, gap: 6 },
  tab: { flex: 1, paddingVertical: 8, borderRadius: 10, backgroundColor: Colors.bgCard, alignItems: 'center', borderWidth: 1, borderColor: Colors.border },
  tabActive: { backgroundColor: Colors.accentDim, borderColor: Colors.accent },
  tabText: { fontFamily: 'Inter_500Medium', fontSize: 12, color: Colors.textMuted },
  tabTextActive: { color: Colors.accent },
  scrollContent: { padding: 12, gap: 10 },
  card: { backgroundColor: Colors.bgCard, borderRadius: 14, padding: 14, borderWidth: 1, borderColor: Colors.border, marginBottom: 10 },
  cardTitle: { fontFamily: 'Inter_700Bold', fontSize: 15, color: Colors.text, marginBottom: 12 },
  marketRow: { flexDirection: 'row' },
  marketItem: { paddingVertical: 8, alignItems: 'center', gap: 2 },
  marketValue: { fontFamily: 'Inter_700Bold', fontSize: 24, color: Colors.text },
  marketLabel: { fontFamily: 'Inter_400Regular', fontSize: 11, color: Colors.textMuted },
  factorRow: { flexDirection: 'row', alignItems: 'flex-start', gap: 8, marginBottom: 8 },
  factorText: { flex: 1, fontFamily: 'Inter_400Regular', fontSize: 13, color: Colors.textSecondary, lineHeight: 18 },
  tipsContainer: {
    backgroundColor: Colors.bgCard,
    borderRadius: 14, padding: 14,
    borderWidth: 1, borderColor: Colors.border,
    marginBottom: 10, gap: 10,
  },
  tipsTitle: { fontFamily: 'Inter_700Bold', fontSize: 15, color: Colors.text, marginBottom: 2 },
  tipCard: {
    flexDirection: 'row', alignItems: 'flex-start', gap: 12,
    backgroundColor: Colors.bgCardDark, borderRadius: 12, padding: 12,
    borderWidth: 1, borderColor: Colors.border,
    borderLeftWidth: 3,
  },
  tipIconBox: {
    width: 36, height: 36, borderRadius: 10,
    alignItems: 'center', justifyContent: 'center',
    flexShrink: 0,
  },
  tipBody: { flex: 1, gap: 4 },
  tipHeaderRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 8 },
  tipMarket: { flex: 1, fontFamily: 'Inter_700Bold', fontSize: 13, color: Colors.text },
  tipReason: { fontFamily: 'Inter_400Regular', fontSize: 12, color: Colors.textSecondary, lineHeight: 17 },
  tipBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 5,
    paddingHorizontal: 8, paddingVertical: 3,
    borderRadius: 8, borderWidth: 1,
  },
  tipBadgeDot: { width: 5, height: 5, borderRadius: 3 },
  tipConf: { fontFamily: 'Inter_700Bold', fontSize: 11 },
  noDataText: { fontFamily: 'Inter_400Regular', fontSize: 13, color: Colors.textMuted },
  recentMatch: { flexDirection: 'row', alignItems: 'center', paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: Colors.border, gap: 8 },
  resultDot: { width: 8, height: 8, borderRadius: 4 },
  recentOpponent: { flex: 1, fontFamily: 'Inter_500Medium', fontSize: 12, color: Colors.text },
  recentDate: { fontFamily: 'Inter_400Regular', fontSize: 11, color: Colors.textMuted },
  recentScore: { fontFamily: 'Inter_700Bold', fontSize: 14, color: Colors.text },
  h2hSummaryRow: { flexDirection: 'row', justifyContent: 'space-around', marginBottom: 12 },
  h2hItem: { alignItems: 'center', gap: 4 },
  h2hCount: { fontFamily: 'Inter_700Bold', fontSize: 28 },
  h2hLabel: { fontFamily: 'Inter_400Regular', fontSize: 11, color: Colors.textMuted, maxWidth: 80, textAlign: 'center' },
  h2hBar: { height: 8, borderRadius: 4, flexDirection: 'row', overflow: 'hidden', marginBottom: 10, gap: 2 },
  h2hBarHome: { backgroundColor: Colors.home },
  h2hBarDraw: { backgroundColor: Colors.amber },
  h2hBarAway: { backgroundColor: Colors.away },
  h2hAvgRow: { flexDirection: 'row', alignItems: 'center', gap: 5, marginBottom: 12 },
  h2hAvgText: { fontFamily: 'Inter_400Regular', fontSize: 12, color: Colors.textMuted },
  h2hMatch: { paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: Colors.border },
  h2hMatchDate: { fontFamily: 'Inter_400Regular', fontSize: 11, color: Colors.textMuted, marginBottom: 4 },
  h2hMatchTeams: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  h2hMatchTeam: { flex: 1, fontFamily: 'Inter_500Medium', fontSize: 13, color: Colors.text },
  h2hMatchScore: { fontFamily: 'Inter_700Bold', fontSize: 15, color: Colors.text, paddingHorizontal: 8 },
  mlIntroText: { fontFamily: 'Inter_400Regular', fontSize: 12, color: Colors.textMuted, lineHeight: 18, marginBottom: 12 },
  compRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 6 },
  compDataRow: { borderTopWidth: 1, borderTopColor: Colors.border },
  compLabel: { flex: 1.2, fontFamily: 'Inter_500Medium', fontSize: 12, color: Colors.textMuted },
  compHome: { flex: 1, fontFamily: 'Inter_600SemiBold', fontSize: 13, textAlign: 'center', color: Colors.textMuted },
  compDraw: { flex: 1, fontFamily: 'Inter_600SemiBold', fontSize: 13, textAlign: 'center', color: Colors.textMuted },
  compAway: { flex: 1, fontFamily: 'Inter_600SemiBold', fontSize: 13, textAlign: 'center', color: Colors.textMuted },
  mlNote: { fontFamily: 'Inter_400Regular', fontSize: 11, color: Colors.textMuted, marginTop: 10, lineHeight: 16 },
  trainingGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 10 },
  trainingCard: { flex: 1, minWidth: '40%', backgroundColor: Colors.bgCardDark, borderRadius: 10, padding: 12, alignItems: 'center', gap: 4, borderWidth: 1, borderColor: Colors.border },
  trainingValue: { fontFamily: 'Inter_700Bold', fontSize: 22, color: Colors.text },
  trainingLabel: { fontFamily: 'Inter_400Regular', fontSize: 11, color: Colors.textMuted },
  howRow: { flexDirection: 'row', alignItems: 'flex-start', gap: 10, marginBottom: 10 },
  howStep: { width: 22, height: 22, borderRadius: 11, backgroundColor: Colors.accentDim, alignItems: 'center', justifyContent: 'center', marginTop: 1 },
  howNum: { fontFamily: 'Inter_700Bold', fontSize: 11, color: Colors.accent },
  howText: { flex: 1, fontFamily: 'Inter_400Regular', fontSize: 12, color: Colors.textSecondary, lineHeight: 18 },
  loadingState: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 12 },
  loadingTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 17, color: Colors.text },
  loadingSubtitle: { fontFamily: 'Inter_400Regular', fontSize: 13, color: Colors.textMuted },
  errorState: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 12 },
  errorTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 17, color: Colors.textSecondary },
  errorSubtitle: { fontFamily: 'Inter_400Regular', fontSize: 13, color: Colors.textMuted, textAlign: 'center' },
  retryBtn: { backgroundColor: Colors.accent, paddingHorizontal: 24, paddingVertical: 12, borderRadius: 12, marginTop: 4 },
  retryText: { fontFamily: 'Inter_600SemiBold', fontSize: 15, color: '#fff' },
});

const aStyles = StyleSheet.create({
  barTrack: { height: 5, backgroundColor: Colors.border, borderRadius: 3, overflow: 'hidden' },
  barFill: { height: '100%', borderRadius: 3 },
});

const fStyles = StyleSheet.create({
  teamFormRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  teamDot: { width: 8, height: 8, borderRadius: 4 },
  teamLabel: { flex: 1, fontFamily: 'Inter_500Medium', fontSize: 12, color: Colors.text },
  badgeRow: { flexDirection: 'row', gap: 4 },
  badge: { width: 22, height: 22, borderRadius: 6, alignItems: 'center', justifyContent: 'center' },
  badgeText: { fontFamily: 'Inter_700Bold', fontSize: 11 },
});

const sStyles = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', marginBottom: 10, gap: 8 },
  val: { fontFamily: 'Inter_600SemiBold', fontSize: 13, color: Colors.text, width: 44 },
  bars: { flex: 1, gap: 4 },
  label: { fontFamily: 'Inter_400Regular', fontSize: 11, color: Colors.textMuted, textAlign: 'center' },
  barRow: { flexDirection: 'row', height: 5, borderRadius: 3, overflow: 'hidden', gap: 2 },
  homeBar: { backgroundColor: Colors.home, borderRadius: 3 },
  awayBar: { backgroundColor: Colors.away, borderRadius: 3 },
});
