import React, { useState, useCallback, useMemo, useRef, useEffect } from 'react';
import {
  View, Text, StyleSheet, Pressable, SectionList,
  ActivityIndicator, RefreshControl, Platform, ScrollView,
} from 'react-native';
import { router } from 'expo-router';
import { Ionicons, MaterialCommunityIcons, Feather } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useQuery } from '@tanstack/react-query';
import { getApiUrl } from '../../lib/api';
import { Colors } from '../../constants/colors';

interface League { name: string; id?: number }
interface Match {
  id: number | string;
  homeTeam?: { name?: string };
  awayTeam?: { name?: string };
  homeResult?: number | null;
  awayResult?: number | null;
  statusName?: string;
  status?: number | string;
  date?: string;
  time?: string;
  league?: League | string;
  season?: { league?: League };
}
interface SectionData { title: string; totalCount: number; data: Match[] }

function isLive(m: Match): boolean {
  const NOT_STARTED = new Set(['not started', 'scheduled', 'tbd', 'ns', '']);
  const ENDED = new Set(['finished', 'ended', 'ft', 'full time', 'fulltime', 'finished after extra time', 'finished after penalty', 'aet', 'pen', 'after penalties']);
  const CANCELLED = new Set(['postponed', 'cancelled', 'abandoned', 'suspended', 'walkover', 'awarded']);
  const name = String(m.statusName || '').toLowerCase().trim();
  if (NOT_STARTED.has(name)) return false;
  if (ENDED.has(name)) return false;
  if (CANCELLED.has(name)) return false;
  if (!name) {
    const num = Number(m.status);
    if (num === 2 || (num >= 8 && num <= 14)) return false;
    return !isNaN(num) && num > 0;
  }
  return true;
}

function isFinished(m: Match): boolean {
  const ENDED = new Set(['finished', 'ended', 'ft', 'full time', 'fulltime', 'finished after extra time', 'finished after penalty', 'aet', 'pen', 'after penalties', 'finished after penalties']);
  const name = String(m.statusName || '').toLowerCase().trim();
  if (ENDED.has(name)) return true;
  const num = Number(m.status);
  return (num === 8 || num === 9 || num === 10);
}

function isUpcoming(m: Match): boolean {
  const NOT_STARTED = new Set(['not started', 'scheduled', 'tbd', 'ns', '']);
  const name = String(m.statusName || '').toLowerCase().trim();
  if (NOT_STARTED.has(name)) return true;
  const num = Number(m.status);
  return num === 2;
}

function formatDate(d: Date): string {
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

const DAY_NAMES = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'];

function buildDateRange(): Date[] {
  const dates: Date[] = [];
  const today = new Date();
  for (let i = -14; i <= 30; i++) {
    const d = new Date(today);
    d.setDate(today.getDate() + i);
    dates.push(d);
  }
  return dates;
}

interface DatePickerProps {
  selected: string;
  onSelect: (d: string) => void;
  matchCounts: Record<string, number>;
}

function DatePicker({ selected, onSelect, matchCounts }: DatePickerProps) {
  const dates = useMemo(() => buildDateRange(), []);
  const today = formatDate(new Date());
  const scrollRef = useRef<ScrollView>(null);

  useEffect(() => {
    const selectedIdx = dates.findIndex((d) => formatDate(d) === selected);
    if (scrollRef.current && selectedIdx >= 0) {
      setTimeout(() => {
        scrollRef.current?.scrollTo({ x: selectedIdx * 64, animated: true });
      }, 150);
    }
  }, [selected, dates]);

  return (
    <ScrollView
      ref={scrollRef}
      horizontal
      showsHorizontalScrollIndicator={false}
      contentContainerStyle={styles.datePicker}
      decelerationRate="fast"
    >
      {dates.map((d) => {
        const key = formatDate(d);
        const isSelected = key === selected;
        const isToday = key === today;
        const count = matchCounts[key];
        return (
          <Pressable
            key={key}
            onPress={() => onSelect(key)}
            style={[
              styles.dateItem,
              isSelected && styles.dateItemSelected,
              !isSelected && isToday && styles.dateItemToday,
            ]}
          >
            <Text style={[styles.dateItemDay, isSelected ? styles.dateItemTextSelected : { color: Colors.textMuted }]}>
              {isToday ? 'TODAY' : DAY_NAMES[d.getDay()]}
            </Text>
            <Text style={[styles.dateItemNum, isSelected ? styles.dateItemTextSelected : { color: Colors.text }]}>
              {d.getDate()}
            </Text>
            <Text style={[styles.dateItemMonth, isSelected ? styles.dateItemTextSelected : { color: Colors.textMuted }]}>
              {d.toLocaleDateString('en-US', { month: 'short' }).toUpperCase()}
            </Text>
            {count !== undefined && count > 0 && (
              <View style={[styles.dateCountBadge, isSelected && styles.dateCountBadgeSelected]}>
                <Text style={[styles.dateCountText, isSelected && styles.dateCountTextSelected]}>{count}</Text>
              </View>
            )}
          </Pressable>
        );
      })}
    </ScrollView>
  );
}

function getLeagueName(m: Match): string {
  if (typeof m.league === 'string') return m.league;
  if (m.league && typeof m.league === 'object') return m.league.name || 'Unknown';
  const s = m.season as { league?: { name?: string } } | undefined;
  return s?.league?.name || 'Unknown';
}

function getInitials(name?: string): string {
  if (!name) return '?';
  const parts = name.trim().split(/\s+/);
  if (parts.length === 1) return parts[0].substring(0, 3).toUpperCase();
  return parts.slice(0, 2).map((p) => p[0]).join('').toUpperCase();
}

interface MatchCardProps { match: Match; onPress: () => void }
function MatchCard({ match, onPress }: MatchCardProps) {
  const live = isLive(match);
  const finished = isFinished(match);
  const homeInitials = getInitials(match.homeTeam?.name);
  const awayInitials = getInitials(match.awayTeam?.name);

  const statusText = match.statusName
    ? match.statusName.charAt(0).toUpperCase() + match.statusName.slice(1).toLowerCase()
    : match.time || '-';

  return (
    <Pressable style={styles.matchCard} onPress={onPress}>
      <View style={styles.matchCardInner}>
        <View style={styles.teamRow}>
          <View style={styles.teamSide}>
            <View style={styles.teamBadge}>
              <Text style={styles.teamBadgeText}>{homeInitials}</Text>
            </View>
            <Text style={styles.teamName} numberOfLines={1}>{match.homeTeam?.name || 'TBD'}</Text>
          </View>

          <View style={styles.scoreBox}>
            {live ? (
              <View style={styles.liveBox}>
                <View style={styles.livePulse} />
                <Text style={styles.liveText}>LIVE</Text>
              </View>
            ) : finished ? (
              <View style={styles.scoreDisplay}>
                <Text style={styles.scoreText}>{match.homeResult ?? '?'}</Text>
                <Text style={styles.scoreSep}>:</Text>
                <Text style={styles.scoreText}>{match.awayResult ?? '?'}</Text>
              </View>
            ) : (
              <Text style={styles.matchTime}>{match.time || '–:––'}</Text>
            )}
          </View>

          <View style={[styles.teamSide, styles.teamSideAway]}>
            <Text style={[styles.teamName, styles.teamNameAway]} numberOfLines={1}>{match.awayTeam?.name || 'TBD'}</Text>
            <View style={[styles.teamBadge, styles.teamBadgeAway]}>
              <Text style={styles.teamBadgeText}>{awayInitials}</Text>
            </View>
          </View>
        </View>

        <View style={styles.matchCardFooter}>
          <MaterialCommunityIcons name="chart-line" size={12} color={Colors.accent} />
          <Text style={styles.analysisHint}>Tap to analyze</Text>
        </View>
      </View>
    </Pressable>
  );
}

interface LeagueSectionProps {
  section: SectionData;
  onMatchPress: (id: number | string) => void;
}
function LeagueSection({ section, onMatchPress }: LeagueSectionProps) {
  const [expanded, setExpanded] = useState(true);
  const initials = section.title.substring(0, 2).toUpperCase();
  return (
    <View style={styles.leagueSection}>
      <Pressable style={styles.leagueHeader} onPress={() => setExpanded((e) => !e)}>
        <View style={styles.leagueBadge}>
          <Text style={{ fontFamily: 'Inter_700Bold', fontSize: 9, color: Colors.accent }}>{initials}</Text>
        </View>
        <Text style={styles.leagueName} numberOfLines={1}>{section.title}</Text>
        <Text style={styles.leagueCount}>{section.totalCount}</Text>
        <Feather name={expanded ? 'chevron-up' : 'chevron-down'} size={14} color={Colors.textMuted} />
      </Pressable>
      {expanded && section.data.map((m) => (
        <MatchCard key={m.id} match={m} onPress={() => onMatchPress(m.id)} />
      ))}
    </View>
  );
}

async function fetchMatches(date: string): Promise<Match[]> {
  const apiUrl = getApiUrl();
  const res = await fetch(`${apiUrl}/api/matches?date=${date}`);
  if (!res.ok) throw new Error(`Failed: ${res.status}`);
  const data = await res.json() as { matches?: Match[] };
  return data.matches || [];
}

export default function MatchesScreen() {
  const insets = useSafeAreaInsets();
  const [selectedDate, setSelectedDate] = useState(() => formatDate(new Date()));
  const [filter, setFilter] = useState<'all' | 'live' | 'upcoming' | 'finished'>('all');

  const { data: matches = [], isLoading, isError, error, refetch, isFetching } = useQuery({
    queryKey: ['matches', selectedDate],
    queryFn: () => fetchMatches(selectedDate),
    refetchInterval: selectedDate === formatDate(new Date()) ? 30000 : undefined,
  });

  const matchCounts = useMemo<Record<string, number>>(() => {
    const counts: Record<string, number> = {};
    const today = formatDate(new Date());
    counts[today] = (counts[today] || 0) + matches.length;
    return counts;
  }, [matches]);

  const filteredMatches = useMemo(() => {
    if (filter === 'all') return matches;
    if (filter === 'live') return matches.filter(isLive);
    if (filter === 'upcoming') return matches.filter(isUpcoming);
    if (filter === 'finished') return matches.filter(isFinished);
    return matches;
  }, [matches, filter]);

  const sections = useMemo<SectionData[]>(() => {
    const leagueMap = new Map<string, Match[]>();
    for (const m of filteredMatches) {
      const league = getLeagueName(m);
      if (!leagueMap.has(league)) leagueMap.set(league, []);
      leagueMap.get(league)!.push(m);
    }
    return Array.from(leagueMap.entries()).map(([title, data]) => ({
      title,
      totalCount: data.length,
      data,
    }));
  }, [filteredMatches]);

  const handleMatchPress = useCallback((id: number | string) => {
    router.push({ pathname: '/[id]', params: { id: String(id) } });
  }, []);

  const liveCount = useMemo(() => matches.filter(isLive).length, [matches]);

  const tabBarHeight = Platform.OS === 'web' ? 84 : 80;
  const bottomPad = insets.bottom + tabBarHeight;
  const topPad = insets.top + (Platform.OS === 'web' ? 67 : 0);

  return (
    <View style={[styles.container, { paddingTop: topPad }]}>
      <View style={styles.header}>
        <View style={styles.headerLeft}>
          <MaterialCommunityIcons name="soccer" size={22} color={Colors.accent} />
          <Text style={styles.headerTitle}>Matches</Text>
          {liveCount > 0 && (
            <View style={styles.liveBadge}>
              <View style={styles.liveDot} />
              <Text style={styles.liveBadgeText}>{liveCount} LIVE</Text>
            </View>
          )}
        </View>
        {isFetching && !isLoading && (
          <ActivityIndicator size="small" color={Colors.accent} />
        )}
      </View>

      <View style={styles.datePickerWrapper}>
        <DatePicker
          selected={selectedDate}
          onSelect={setSelectedDate}
          matchCounts={matchCounts}
        />
      </View>

      <View style={styles.filterRow}>
        {(['all', 'live', 'upcoming', 'finished'] as const).map((f) => (
          <Pressable
            key={f}
            style={[styles.filterBtn, filter === f && styles.filterBtnActive]}
            onPress={() => setFilter(f)}
          >
            <Text style={[styles.filterText, filter === f && styles.filterTextActive]}>
              {f === 'all' ? 'All' : f === 'live' ? 'Live' : f === 'upcoming' ? 'Upcoming' : 'Finished'}
            </Text>
          </Pressable>
        ))}
      </View>

      {isLoading ? (
        <View style={styles.centered}>
          <ActivityIndicator size="large" color={Colors.accent} />
          <Text style={styles.loadingText}>Loading matches...</Text>
        </View>
      ) : isError ? (
        <View style={styles.centered}>
          <MaterialCommunityIcons name="wifi-off" size={40} color={Colors.textMuted} />
          <Text style={styles.errorText}>
            {error instanceof Error ? error.message : 'Failed to load matches'}
          </Text>
          <Pressable style={styles.retryBtn} onPress={() => refetch()}>
            <Text style={styles.retryText}>Retry</Text>
          </Pressable>
        </View>
      ) : filteredMatches.length === 0 ? (
        <View style={styles.centered}>
          <MaterialCommunityIcons name="calendar-blank" size={48} color={Colors.textMuted} />
          <Text style={styles.emptyText}>No matches found</Text>
          <Text style={styles.emptySubtext}>Try a different date or filter</Text>
        </View>
      ) : (
        <SectionList
          sections={sections}
          keyExtractor={(item) => String(item.id)}
          contentContainerStyle={{ paddingHorizontal: 12, paddingBottom: bottomPad, paddingTop: 8 }}
          renderItem={() => null}
          renderSectionHeader={({ section }) => (
            <LeagueSection
              section={section as SectionData}
              onMatchPress={handleMatchPress}
            />
          )}
          showsVerticalScrollIndicator={false}
          refreshControl={
            <RefreshControl
              refreshing={isFetching && !isLoading}
              onRefresh={refetch}
              tintColor={Colors.accent}
            />
          }
          stickySectionHeadersEnabled={false}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 16, paddingVertical: 10,
  },
  headerLeft: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  headerTitle: { fontFamily: 'Inter_700Bold', fontSize: 22, color: Colors.text },
  liveBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    backgroundColor: Colors.redDim, paddingHorizontal: 8, paddingVertical: 3, borderRadius: 8,
  },
  liveDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: Colors.red },
  liveBadgeText: { fontFamily: 'Inter_700Bold', fontSize: 10, color: Colors.red },
  datePickerWrapper: {
    backgroundColor: '#111827',
    borderTopWidth: 1,
    borderBottomWidth: 1,
    borderColor: '#1E2D45',
  },
  datePicker: { paddingHorizontal: 12, paddingVertical: 10, gap: 7 },
  dateItem: {
    width: 62, alignItems: 'center', paddingVertical: 10, paddingHorizontal: 4,
    borderRadius: 14, backgroundColor: '#1E2D45', gap: 2,
    borderWidth: 1.5, borderColor: '#2A3F60',
  },
  dateItemSelected: { backgroundColor: Colors.accent, borderColor: Colors.accent },
  dateItemToday: { borderColor: Colors.accent, backgroundColor: '#0D2A1E' },
  dateItemDay: { fontFamily: 'Inter_600SemiBold', fontSize: 10, color: Colors.textSecondary },
  dateItemNum: { fontFamily: 'Inter_700Bold', fontSize: 20, color: Colors.text },
  dateItemMonth: { fontFamily: 'Inter_500Medium', fontSize: 9, color: Colors.textSecondary },
  dateItemTextSelected: { color: '#fff' },
  dateCountBadge: {
    marginTop: 3, backgroundColor: '#2A3F60', borderRadius: 6,
    paddingHorizontal: 6, paddingVertical: 2,
  },
  dateCountBadgeSelected: { backgroundColor: 'rgba(255,255,255,0.3)' },
  dateCountText: { fontFamily: 'Inter_700Bold', fontSize: 9, color: Colors.textSecondary },
  dateCountTextSelected: { color: '#fff' },
  filterRow: {
    flexDirection: 'row', paddingHorizontal: 12, paddingVertical: 6, gap: 8,
  },
  filterBtn: {
    paddingHorizontal: 16, paddingVertical: 6, borderRadius: 20,
    backgroundColor: Colors.bgCard, borderWidth: 1, borderColor: Colors.border,
  },
  filterBtnActive: { backgroundColor: Colors.accentDim, borderColor: Colors.accent },
  filterText: { fontFamily: 'Inter_500Medium', fontSize: 13, color: Colors.textMuted },
  filterTextActive: { color: Colors.accent },
  leagueSection: { marginBottom: 10 },
  leagueHeader: {
    flexDirection: 'row', alignItems: 'center', paddingHorizontal: 10, paddingVertical: 8,
    backgroundColor: Colors.bgCard, borderRadius: 10, marginBottom: 4, gap: 6,
  },
  leagueBadge: {
    width: 22, height: 22, borderRadius: 6, backgroundColor: Colors.accentDim,
    alignItems: 'center', justifyContent: 'center',
  },
  leagueName: { flex: 1, fontFamily: 'Inter_600SemiBold', fontSize: 13, color: Colors.text },
  leagueCount: { fontFamily: 'Inter_400Regular', fontSize: 12, color: Colors.textMuted, marginRight: 4 },
  matchCard: {
    marginBottom: 4, borderRadius: 10, backgroundColor: Colors.bgCardDark,
    borderWidth: 1, borderColor: Colors.border, overflow: 'hidden',
  },
  matchCardInner: { padding: 12 },
  teamRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  teamSide: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 8 },
  teamSideAway: { justifyContent: 'flex-end' },
  teamBadge: {
    width: 32, height: 32, borderRadius: 8, backgroundColor: Colors.blueDim,
    alignItems: 'center', justifyContent: 'center',
  },
  teamBadgeAway: { backgroundColor: Colors.purpleDim },
  teamBadgeText: { fontFamily: 'Inter_700Bold', fontSize: 10, color: Colors.text },
  teamName: { flex: 1, fontFamily: 'Inter_500Medium', fontSize: 13, color: Colors.text },
  teamNameAway: { textAlign: 'right' },
  scoreBox: { width: 72, alignItems: 'center', justifyContent: 'center' },
  scoreDisplay: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  scoreText: { fontFamily: 'Inter_700Bold', fontSize: 20, color: Colors.text },
  scoreSep: { fontFamily: 'Inter_700Bold', fontSize: 16, color: Colors.textMuted },
  liveBox: {
    flexDirection: 'row', alignItems: 'center', gap: 5,
    backgroundColor: '#1A0A0A', paddingHorizontal: 8, paddingVertical: 4,
    borderRadius: 8, borderWidth: 1, borderColor: Colors.red,
  },
  livePulse: { width: 6, height: 6, borderRadius: 3, backgroundColor: Colors.red },
  liveText: { fontFamily: 'Inter_700Bold', fontSize: 11, color: Colors.red },
  matchTime: { fontFamily: 'Inter_600SemiBold', fontSize: 15, color: Colors.textSecondary },
  matchCardFooter: {
    flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 8,
    paddingTop: 6, borderTopWidth: 1, borderTopColor: Colors.border,
  },
  analysisHint: { fontFamily: 'Inter_400Regular', fontSize: 11, color: Colors.accent },
  centered: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 12 },
  loadingText: { fontFamily: 'Inter_400Regular', fontSize: 14, color: Colors.textMuted },
  errorText: { fontFamily: 'Inter_500Medium', fontSize: 15, color: Colors.textSecondary, marginTop: 8, textAlign: 'center' },
  emptyText: { fontFamily: 'Inter_600SemiBold', fontSize: 16, color: Colors.textSecondary },
  emptySubtext: { fontFamily: 'Inter_400Regular', fontSize: 14, color: Colors.textMuted },
  retryBtn: { backgroundColor: Colors.accent, paddingHorizontal: 24, paddingVertical: 10, borderRadius: 10, marginTop: 8 },
  retryText: { fontFamily: 'Inter_600SemiBold', fontSize: 14, color: '#fff' },
});
