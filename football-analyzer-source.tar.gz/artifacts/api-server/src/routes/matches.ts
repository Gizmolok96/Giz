import { Router, type IRouter } from 'express';
import * as mlModel from '../ml/model.js';

const router: IRouter = Router();

const SSTATS_API_KEY = 'gbi1ldi9446kastj';
const SSTATS_BASE_URL = 'https://api.sstats.net';

const requestCache = new Map<string, { data: unknown; ts: number }>();
const CACHE_TTL_LIVE = 30 * 1000;
const CACHE_TTL_SHORT = 5 * 60 * 1000;
const CACHE_TTL_LONG = 30 * 60 * 1000;

async function sstatsRequest(
  endpoint: string,
  params: Record<string, string | number> = {},
  ttl = CACHE_TTL_LONG
): Promise<unknown> {
  const url = new URL(`${SSTATS_BASE_URL}${endpoint}`);
  url.searchParams.set('apikey', SSTATS_API_KEY);
  for (const [k, v] of Object.entries(params)) {
    url.searchParams.set(k, String(v));
  }
  const cacheKey = url.toString();
  const cached = requestCache.get(cacheKey);
  if (cached && Date.now() - cached.ts < ttl) return cached.data;
  const res = await fetch(url.toString(), {
    headers: { 'User-Agent': 'SStats-Mobile-App/1.0', Accept: 'application/json' },
  });
  if (!res.ok) throw new Error(`API error: ${res.status} ${res.statusText}`);
  const data = await res.json();
  requestCache.set(cacheKey, { data, ts: Date.now() });
  return data;
}

function getLeagueName(match: Record<string, unknown>): string {
  const season = match.season as Record<string, unknown> | undefined;
  if (season?.league) return ((season.league as Record<string, unknown>).name as string) || 'Unknown';
  const league = match.league as Record<string, unknown> | undefined;
  return (league?.name as string) || 'Unknown';
}

function poissonPmf(k: number, lambda: number): number {
  if (k < 0 || lambda <= 0) return 0;
  let logP = -lambda;
  for (let i = 1; i <= k; i++) logP += Math.log(lambda) - Math.log(i);
  return Math.exp(logP);
}

interface TeamStat {
  goals_for: number;
  goals_against: number;
  xg_for: number | null;
  xg_against: number | null;
  possession: number;
  shots: number;
  shots_on_target: number;
  result: 'W' | 'D' | 'L';
  is_home: boolean;
  date: string;
  opponent: string;
}

function extractTeamStats(matchData: Record<string, unknown>, teamId: number): TeamStat | null {
  const homeTeam = (matchData.homeTeam as Record<string, unknown>) || {};
  const awayTeam = (matchData.awayTeam as Record<string, unknown>) || {};
  const homeId = homeTeam.id as number;
  const awayId = awayTeam.id as number;
  if (homeId !== teamId && awayId !== teamId) return null;
  const isHome = homeId === teamId;
  const goalsFor = isHome ? ((matchData.homeResult as number) ?? 0) : ((matchData.awayResult as number) ?? 0);
  const goalsAgainst = isHome ? ((matchData.awayResult as number) ?? 0) : ((matchData.homeResult as number) ?? 0);
  if ((matchData.homeResult as number) === null && (matchData.awayResult as number) === null) return null;
  let result: 'W' | 'D' | 'L' = 'D';
  if (goalsFor > goalsAgainst) result = 'W';
  else if (goalsFor < goalsAgainst) result = 'L';
  const stats = (matchData.statistics as Record<string, unknown>) || {};
  const suffix = isHome ? 'Home' : 'Away';
  const oppSuffix = isHome ? 'Away' : 'Home';
  const xgFor = (stats[`expectedGoals${suffix}`] as number | null) ?? null;
  const xgAgainst = (stats[`expectedGoals${oppSuffix}`] as number | null) ?? null;
  const possession = (stats[`ballPossession${suffix}`] as number | null) ?? 50;
  const shots = (stats[`totalShots${suffix}`] as number | null) ?? 0;
  const shotsOnTarget = (stats[`shotsOnGoal${suffix}`] as number | null) ?? 0;
  return {
    goals_for: goalsFor, goals_against: goalsAgainst,
    xg_for: xgFor, xg_against: xgAgainst,
    possession: typeof possession === 'number' ? possession : 50,
    shots: typeof shots === 'number' ? shots : 0,
    shots_on_target: typeof shotsOnTarget === 'number' ? shotsOnTarget : 0,
    result, is_home: isHome, date: matchData.date as string,
    opponent: isHome ? (awayTeam.name as string) : (homeTeam.name as string),
  };
}

interface TeamFeatures {
  pointsPerGame: number; winRate: number; drawRate: number; lossRate: number;
  avgGoalsFor: number; avgGoalsAgainst: number; xgForAvg: number; xgAgainstAvg: number;
  avgPossession: number; avgShots: number; avgShotsOnTarget: number;
  recentPoints: number; recentGoalsFor: number; recentGoalsAgainst: number;
  trend: number; homeAdvantage: number; totalMatches: number; formString: string;
}

function calculateTeamFeatures(stats: TeamStat[], isHome: boolean): TeamFeatures {
  if (!stats.length) {
    return {
      pointsPerGame: 1.0, winRate: 0.33, drawRate: 0.33, lossRate: 0.34,
      avgGoalsFor: 1.3, avgGoalsAgainst: 1.3, xgForAvg: 1.3, xgAgainstAvg: 1.3,
      avgPossession: 50, avgShots: 12, avgShotsOnTarget: 4,
      recentPoints: 7, recentGoalsFor: 6.5, recentGoalsAgainst: 6.5,
      trend: 0, homeAdvantage: isHome ? 1.4 : 0.85, totalMatches: 0, formString: '-----',
    };
  }
  const total = stats.length;
  const wins = stats.filter((s) => s.result === 'W').length;
  const draws = stats.filter((s) => s.result === 'D').length;
  const losses = total - wins - draws;
  const sumGoalsFor = stats.reduce((a, s) => a + s.goals_for, 0);
  const sumGoalsAgainst = stats.reduce((a, s) => a + s.goals_against, 0);
  const xgForList = stats.filter((s) => s.xg_for !== null && s.xg_for > 0).map((s) => s.xg_for as number);
  const xgAgainstList = stats.filter((s) => s.xg_against !== null && s.xg_against > 0).map((s) => s.xg_against as number);
  const xgForAvg = xgForList.length ? xgForList.reduce((a, x) => a + x, 0) / xgForList.length : sumGoalsFor / total;
  const xgAgainstAvg = xgAgainstList.length ? xgAgainstList.reduce((a, x) => a + x, 0) / xgAgainstList.length : sumGoalsAgainst / total;
  const avgPossession = stats.reduce((a, s) => a + s.possession, 0) / total;
  const avgShots = stats.reduce((a, s) => a + s.shots, 0) / total;
  const avgShotsOnTarget = stats.reduce((a, s) => a + s.shots_on_target, 0) / total;
  const recent = stats.slice(0, 5);
  const pointsMap: Record<string, number> = { W: 3, D: 1, L: 0 };
  const recentPoints = recent.reduce((a, s) => a + pointsMap[s.result], 0);
  const recentGoalsFor = recent.reduce((a, s) => a + s.goals_for, 0);
  const recentGoalsAgainst = recent.reduce((a, s) => a + s.goals_against, 0);
  const formString = stats.slice(0, 5).map((s) => s.result).join('');
  let trend = 0;
  if (recent.length >= 3) {
    const mid = Math.floor(recent.length / 2);
    const first = recent.slice(0, mid);
    const second = recent.slice(mid);
    const ppgFirst = first.reduce((a, s) => a + pointsMap[s.result], 0) / first.length;
    const ppgSecond = second.reduce((a, s) => a + pointsMap[s.result], 0) / second.length;
    trend = Math.max(-1, Math.min(1, (ppgFirst - ppgSecond) / 1.5));
  }
  const homeMatches = stats.filter((s) => s.is_home);
  const awayMatches = stats.filter((s) => !s.is_home);
  let homeAdvantage = isHome ? 1.4 : 0.85;
  if (isHome && homeMatches.length > 0 && awayMatches.length > 0) {
    const homePpg = homeMatches.reduce((a, s) => a + pointsMap[s.result], 0) / homeMatches.length;
    const awayPpg = awayMatches.reduce((a, s) => a + pointsMap[s.result], 0) / awayMatches.length;
    homeAdvantage = homePpg / Math.max(awayPpg, 0.1);
  }
  return {
    pointsPerGame: (wins * 3 + draws) / total,
    winRate: wins / total, drawRate: draws / total, lossRate: losses / total,
    avgGoalsFor: sumGoalsFor / total, avgGoalsAgainst: sumGoalsAgainst / total,
    xgForAvg, xgAgainstAvg, avgPossession, avgShots, avgShotsOnTarget,
    recentPoints, recentGoalsFor, recentGoalsAgainst, trend,
    homeAdvantage, totalMatches: total, formString,
  };
}

function detectLeagueContext(leagueName: string) {
  const name = leagueName.toLowerCase();
  if (name.includes('premier league') && name.includes('england')) return { avgGoals: 2.7, homeAdvantage: 1.4, style: 'Physical' };
  if (name.includes('la liga') || name.includes('primera division')) return { avgGoals: 2.5, homeAdvantage: 1.35, style: 'Technical' };
  if (name.includes('serie a')) return { avgGoals: 2.4, homeAdvantage: 1.45, style: 'Tactical' };
  if (name.includes('bundesliga')) return { avgGoals: 3.0, homeAdvantage: 1.3, style: 'Attacking' };
  if (name.includes('ligue 1')) return { avgGoals: 2.3, homeAdvantage: 1.4, style: 'Balanced' };
  if (name.includes('russian') || name.includes('rpl')) return { avgGoals: 2.2, homeAdvantage: 1.5, style: 'Defensive' };
  return { avgGoals: 2.5, homeAdvantage: 1.4, style: 'Balanced' };
}

function calculateXg(features: TeamFeatures, isHome: boolean, leagueCtx: { avgGoals: number; homeAdvantage: number; style: string }): number {
  const base = features.xgForAvg > 0 ? features.xgForAvg : features.avgGoalsFor;
  const locationMult = isHome ? leagueCtx.homeAdvantage * Math.min(Math.max(features.homeAdvantage, 0.5), 2.0) : 0.85;
  const formMult = 1 + features.trend * 0.15;
  return Math.max(0.3, Math.min(base * locationMult * formMult, 3.5));
}

function buildMLFeatures(
  homeFeatures: TeamFeatures, awayFeatures: TeamFeatures,
  h2hHomeWins: number, h2hDraws: number, h2hAwayWins: number,
  h2hAvgGoals: number, homeXg: number, awayXg: number
): mlModel.MLFeatureVector {
  const h2hTotal = h2hHomeWins + h2hDraws + h2hAwayWins;
  return {
    homeWinRate: homeFeatures.winRate, awayWinRate: awayFeatures.winRate,
    homeAvgGoalsFor: homeFeatures.avgGoalsFor, awayAvgGoalsFor: awayFeatures.avgGoalsFor,
    homeAvgGoalsAgainst: homeFeatures.avgGoalsAgainst, awayAvgGoalsAgainst: awayFeatures.avgGoalsAgainst,
    homeRecentPoints: homeFeatures.recentPoints / 15, awayRecentPoints: awayFeatures.recentPoints / 15,
    homeTrend: (homeFeatures.trend + 1) / 2, awayTrend: (awayFeatures.trend + 1) / 2,
    homeXgFor: homeXg, awayXgFor: awayXg,
    h2hHomeWinRate: h2hTotal > 0 ? h2hHomeWins / h2hTotal : 0.35,
    h2hAvgGoals: h2hAvgGoals || 2.5,
    homeAdvantage: Math.min(homeFeatures.homeAdvantage / 2, 1),
    homePPG: Math.min(homeFeatures.pointsPerGame / 3, 1), awayPPG: Math.min(awayFeatures.pointsPerGame / 3, 1),
    homeGoalDiff: homeFeatures.avgGoalsFor - homeFeatures.avgGoalsAgainst,
    awayGoalDiff: awayFeatures.avgGoalsFor - awayFeatures.avgGoalsAgainst,
    formDiff: homeFeatures.recentPoints - awayFeatures.recentPoints,
  };
}

function performAnalysis(
  matchGame: Record<string, unknown>,
  _matchStats: Record<string, unknown>,
  homeStats: TeamStat[],
  awayStats: TeamStat[],
  h2hMatches: Record<string, unknown>[]
) {
  const leagueName = getLeagueName(matchGame);
  const leagueCtx = detectLeagueContext(leagueName);
  const homeFeatures = calculateTeamFeatures(homeStats, true);
  const awayFeatures = calculateTeamFeatures(awayStats, false);
  const homeXg = calculateXg(homeFeatures, true, leagueCtx);
  const awayXg = calculateXg(awayFeatures, false, leagueCtx);
  const maxGoals = 6;
  const scores: Record<string, number> = {};
  let homeWin = 0, draw = 0, awayWin = 0, over25 = 0, btts = 0;
  for (let h = 0; h <= maxGoals; h++) {
    for (let a = 0; a <= maxGoals; a++) {
      const prob = poissonPmf(h, homeXg) * poissonPmf(a, awayXg);
      scores[`${h}-${a}`] = prob;
      if (h > a) homeWin += prob;
      else if (h === a) draw += prob;
      else awayWin += prob;
      if (h + a > 2.5) over25 += prob;
      if (h > 0 && a > 0) btts += prob;
    }
  }
  const total = homeWin + draw + awayWin;
  const homeWinPct = (homeWin / total) * 100;
  const drawPct = (draw / total) * 100;
  const awayWinPct = (awayWin / total) * 100;
  const mostLikelyScore = Object.entries(scores).reduce((a, b) => (b[1] > a[1] ? b : a))[0];
  const mostLikelyProb = scores[mostLikelyScore] * 100;
  const homeTeamId = (matchGame.homeTeam as Record<string, unknown>)?.id as number;
  let h2hHomeWins = 0, h2hDraws = 0, h2hAwayWins = 0, h2hGoalSum = 0;
  for (const m of h2hMatches) {
    const hr = (m.homeResult as number) ?? null;
    const ar = (m.awayResult as number) ?? null;
    if (hr === null || ar === null) continue;
    h2hGoalSum += hr + ar;
    const mHomeId = ((m.homeTeam as Record<string, unknown>)?.id) as number;
    if (hr === ar) h2hDraws++;
    else if ((hr > ar && mHomeId === homeTeamId) || (ar > hr && mHomeId !== homeTeamId)) h2hHomeWins++;
    else h2hAwayWins++;
  }
  const h2hAvgGoals = h2hMatches.length > 0 ? h2hGoalSum / h2hMatches.length : 2.5;
  const mlFeatures = buildMLFeatures(homeFeatures, awayFeatures, h2hHomeWins, h2hDraws, h2hAwayWins, h2hAvgGoals, homeXg, awayXg);
  const [mlHome, mlDraw, mlAway] = mlModel.predict(mlFeatures);
  const modelStats = mlModel.getModelStats();
  const mlConfidence = Math.min(95, 50 + (homeFeatures.totalMatches >= 5 ? 15 : homeFeatures.totalMatches * 2) + (awayFeatures.totalMatches >= 5 ? 15 : awayFeatures.totalMatches * 2) + (h2hMatches.length > 0 ? 5 : 0));
  const modelName = modelStats.totalMatchesTrained > 0
    ? `Gradient Boosting (v${modelStats.modelVersion}, ${modelStats.totalMatchesTrained} matches)`
    : 'Gradient Boosting (initial weights)';
  const mlPrediction = {
    homeWinProb: mlHome, drawProb: mlDraw, awayWinProb: mlAway,
    confidence: mlConfidence, modelUsed: modelName,
    features: { homeForm: mlFeatures.homeRecentPoints, awayForm: mlFeatures.awayRecentPoints, h2hAdvantage: mlFeatures.h2hHomeWinRate - 0.35, homeAdvantage: mlFeatures.homeAdvantage * 0.3 },
    available: true,
    trainingStats: { totalMatchesTrained: modelStats.totalMatchesTrained, accuracy7day: modelStats.accuracy7day, accuracy30day: modelStats.accuracy30day, pendingPredictions: modelStats.pendingPredictions, modelVersion: modelStats.modelVersion },
  };
  const matchId = Number(matchGame.id);
  if (matchId) {
    const statusName = String(matchGame.statusName || '').toLowerCase();
    const isFinished = ['finished', 'ft', 'ended', 'aet'].includes(statusName);
    if (!isFinished) {
      mlModel.savePrediction(matchId, String(matchGame.date || new Date().toISOString()), String((matchGame.homeTeam as Record<string, unknown>)?.name || 'Home'), String((matchGame.awayTeam as Record<string, unknown>)?.name || 'Away'), mlFeatures, [mlHome, mlDraw, mlAway]);
    }
  }
  const tips: { market: string; confidence: string; reason: string }[] = [];
  if (homeWinPct > 60) tips.push({ market: `Home Win (${homeWinPct.toFixed(0)}%)`, confidence: 'high', reason: 'Strong home advantage' });
  else if (awayWinPct > 55) tips.push({ market: `Away Win (${awayWinPct.toFixed(0)}%)`, confidence: 'medium', reason: 'Away team in good form' });
  else if (drawPct > 35 && Math.abs(homeWinPct - awayWinPct) < 10) tips.push({ market: `Draw (${drawPct.toFixed(0)}%)`, confidence: 'medium', reason: 'Evenly matched sides' });
  const expectedTotal = homeXg + awayXg;
  if (expectedTotal > 2.8) tips.push({ market: `Over 2.5 (${(over25 * 100).toFixed(0)}%)`, confidence: over25 > 0.65 ? 'high' : 'medium', reason: 'High scoring expected' });
  else if (expectedTotal < 2.2) tips.push({ market: `Under 2.5 (${((1 - over25) * 100).toFixed(0)}%)`, confidence: 'medium', reason: 'Low scoring expected' });
  if (btts > 0.6) tips.push({ market: `BTTS Yes (${(btts * 100).toFixed(0)}%)`, confidence: 'medium', reason: 'Both teams attack well' });
  const maxMLProb = Math.max(mlHome, mlDraw, mlAway);
  if (maxMLProb === mlHome && mlHome > 0.5) tips.push({ market: `ML: Home Win (${(mlHome * 100).toFixed(0)}%)`, confidence: 'high', reason: 'Gradient Boosting model confirms home advantage' });
  else if (maxMLProb === mlAway && mlAway > 0.45) tips.push({ market: `ML: Away Win (${(mlAway * 100).toFixed(0)}%)`, confidence: 'medium', reason: 'ML model predicts away upset' });
  const keyFactors: string[] = [];
  if (homeFeatures.trend > 0.3) keyFactors.push('Home team on winning streak');
  if (awayFeatures.trend > 0.3) keyFactors.push('Away team in rising form');
  if (homeFeatures.avgGoalsFor > 2.0) keyFactors.push('Home team scores frequently');
  if (awayFeatures.avgGoalsAgainst < 0.8) keyFactors.push('Away team solid defensively');
  if (h2hHomeWins > h2hAwayWins * 2 && h2hHomeWins > 1) keyFactors.push('Historical home dominance in H2H');
  if (homeFeatures.totalMatches === 0 && awayFeatures.totalMatches === 0) keyFactors.push('Limited data — prediction based on defaults');
  if (!keyFactors.length) keyFactors.push('Evenly matched encounter');
  let confidence = 50;
  if (homeFeatures.totalMatches >= 5) confidence += 15;
  if (awayFeatures.totalMatches >= 5) confidence += 15;
  if (homeFeatures.totalMatches >= 3) confidence += 5;
  if (awayFeatures.totalMatches >= 3) confidence += 5;
  if (Math.abs(homeFeatures.trend) < 0.3) confidence += 5;
  confidence = Math.min(confidence, 95);
  return {
    homeXg: parseFloat(homeXg.toFixed(2)), awayXg: parseFloat(awayXg.toFixed(2)),
    homeWinPct: parseFloat(homeWinPct.toFixed(1)), drawPct: parseFloat(drawPct.toFixed(1)), awayWinPct: parseFloat(awayWinPct.toFixed(1)),
    mostLikelyScore, mostLikelyProb: parseFloat(mostLikelyProb.toFixed(1)),
    over25Pct: parseFloat((over25 * 100).toFixed(1)), bttsPct: parseFloat((btts * 100).toFixed(1)),
    expectedTotal: parseFloat(expectedTotal.toFixed(2)),
    homeFeatures, awayFeatures,
    h2h: { homeWins: h2hHomeWins, draws: h2hDraws, awayWins: h2hAwayWins, total: h2hMatches.length, avgGoals: h2hAvgGoals, matches: h2hMatches.slice(0, 10) },
    bettingTips: tips, keyFactors, confidenceScore: confidence, leagueContext: leagueCtx, mlPrediction,
  };
}

async function getTeamStats(teamId: number): Promise<TeamStat[]> {
  const data = await sstatsRequest('/games/list', { team: teamId, ended: 'true', order: -1, limit: 10 }, CACHE_TTL_LONG) as Record<string, unknown>;
  const matches = (Array.isArray(data) ? data : ((data.data || []) as Record<string, unknown>[]));
  const stats: TeamStat[] = [];
  for (const match of matches) {
    const m = match as Record<string, unknown>;
    if (m.homeResult === null || m.awayResult === null) continue;
    const stat = extractTeamStats(m, teamId);
    if (stat && stat.result) stats.push(stat);
  }
  return stats;
}

async function getH2HMatches(team1Id: number, team2Id: number): Promise<Record<string, unknown>[]> {
  try {
    const data = await sstatsRequest('/games/headtohead', { team1: team1Id, team2: team2Id, ended: 'true', limit: 10 }) as Record<string, unknown>;
    const matches = (Array.isArray(data) ? data : ((data.data || []) as Record<string, unknown>[]));
    return matches.sort((a: Record<string, unknown>, b: Record<string, unknown>) => {
      const dateA = new Date(a.date as string || 0).getTime();
      const dateB = new Date(b.date as string || 0).getTime();
      return dateB - dateA;
    });
  } catch {
    return [];
  }
}

const NOT_STARTED_NAMES = new Set(['not started', 'scheduled', 'tbd', 'ns']);
const ENDED_NAMES = new Set(['finished', 'ended', 'ft', 'full time', 'fulltime', 'finished after extra time', 'finished after penalty', 'aet', 'pen', 'after penalties', 'finished after penalties']);
const CANCELLED_NAMES = new Set(['postponed', 'cancelled', 'abandoned', 'suspended', 'walkover', 'awarded']);

function getStatusName(m: Record<string, unknown>): string {
  return String(m.statusName || m.status_name || '').toLowerCase().trim();
}

function isMatchLive(m: Record<string, unknown>): boolean {
  const name = getStatusName(m);
  if (NOT_STARTED_NAMES.has(name)) return false;
  if (ENDED_NAMES.has(name)) return false;
  if (CANCELLED_NAMES.has(name)) return false;
  if (!name) {
    const num = Number(m.status);
    if (num === 2 || (num >= 8 && num <= 14)) return false;
    return !isNaN(num) && num > 0;
  }
  return true;
}

function normalizeMatch(m: Record<string, unknown>): Record<string, unknown> {
  return { ...m, league: (m.season as Record<string, unknown>)?.league || m.league || { name: 'Unknown' } };
}

async function fetchAllPages(endpoint: string, baseParams: Record<string, string | number>, ttl: number, pageSize = 500): Promise<Record<string, unknown>[]> {
  const all: Record<string, unknown>[] = [];
  let offset = 0;
  while (true) {
    const params = { ...baseParams, limit: pageSize, offset };
    const raw = await sstatsRequest(endpoint, params, ttl) as Record<string, unknown>;
    const batch = (Array.isArray(raw) ? raw : ((raw.data || []) as Record<string, unknown>[]));
    all.push(...batch);
    if (batch.length < pageSize) break;
    offset += pageSize;
    if (offset >= pageSize * 10) break;
  }
  return all;
}

router.get('/matches/live', async (_req, res) => {
  try {
    let matches: Record<string, unknown>[] = [];
    try {
      const rawList = await fetchAllPages('/games/live', {}, CACHE_TTL_LIVE);
      matches = rawList.map(normalizeMatch);
    } catch {
      const today = new Date().toISOString().split('T')[0];
      const rawList = await fetchAllPages('/games/list', { date: today }, CACHE_TTL_LIVE);
      matches = rawList.map(normalizeMatch).filter((m) => isMatchLive(m));
    }
    res.set('Cache-Control', 'no-store');
    res.json({ matches });
  } catch (error: unknown) {
    res.status(500).json({ error: error instanceof Error ? error.message : 'Unknown error' });
  }
});

router.get('/matches', async (req, res) => {
  try {
    const { date, leagueid } = req.query;
    const params: Record<string, string | number> = {};
    if (date) params.date = date as string;
    if (leagueid) params.leagueid = leagueid as string;
    const rawList = await fetchAllPages('/games/list', params, CACHE_TTL_SHORT);
    const matches = rawList.map(normalizeMatch);
    res.json({ matches, total: matches.length });
  } catch (error: unknown) {
    res.status(500).json({ error: error instanceof Error ? error.message : 'Unknown error' });
  }
});

router.get('/match/:id', async (req, res) => {
  try {
    const data = await sstatsRequest(`/games/${req.params.id}`, {}, CACHE_TTL_LIVE) as Record<string, unknown>;
    const inner = data.data as Record<string, unknown> | undefined;
    const game = inner?.game || inner || data;
    const statistics = inner?.statistics || {};
    res.set('Cache-Control', 'no-store');
    res.json({ game, statistics });
  } catch (error: unknown) {
    res.status(500).json({ error: error instanceof Error ? error.message : 'Unknown error' });
  }
});

router.get('/match/:id/analyze', async (req, res) => {
  try {
    const rawData = await sstatsRequest(`/games/${req.params.id}`) as Record<string, unknown>;
    const inner = rawData.data as Record<string, unknown> | undefined;
    const matchGame = (inner?.game || inner || rawData) as Record<string, unknown>;
    const matchStats = (inner?.statistics || {}) as Record<string, unknown>;
    const homeTeam = (matchGame.homeTeam as Record<string, unknown>) || {};
    const awayTeam = (matchGame.awayTeam as Record<string, unknown>) || {};
    const homeId = homeTeam.id as number;
    const awayId = awayTeam.id as number;
    if (!homeId || !awayId) {
      res.status(400).json({ error: 'Missing team IDs', matchGame });
      return;
    }
    const [homeStats, awayStats, h2hMatches] = await Promise.all([
      getTeamStats(homeId),
      getTeamStats(awayId),
      getH2HMatches(homeId, awayId),
    ]);
    const analysis = performAnalysis(matchGame, matchStats, homeStats, awayStats, h2hMatches);
    const normalizedMatch = { ...matchGame, league: getLeagueName(matchGame), statistics: matchStats };
    res.json({ match: normalizedMatch, analysis, homeRecentMatches: homeStats, awayRecentMatches: awayStats });
  } catch (error: unknown) {
    console.error('[analyze] Error:', error);
    res.status(500).json({ error: error instanceof Error ? error.message : 'Unknown error' });
  }
});

router.get('/leagues', async (_req, res) => {
  try {
    const data = await sstatsRequest('/leagues') as Record<string, unknown>;
    res.json({ leagues: data.data || [] });
  } catch (error: unknown) {
    res.status(500).json({ error: error instanceof Error ? error.message : 'Unknown error' });
  }
});

router.get('/ml/stats', (_req, res) => {
  res.json(mlModel.getModelStats());
});

router.post('/ml/train', async (_req, res) => {
  try {
    const stats = await mlModel.triggerTraining();
    res.json({ success: true, stats });
  } catch (error: unknown) {
    res.status(500).json({ error: error instanceof Error ? error.message : 'Unknown error' });
  }
});

router.post('/ml/train-from-history', (req, res) => {
  try {
    const { entries } = req.body as { entries: mlModel.HistoryTrainingEntry[] };
    if (!Array.isArray(entries) || entries.length === 0) {
      res.status(400).json({ error: 'entries array is required' });
      return;
    }
    const result = mlModel.trainFromHistory(entries);
    res.json({ success: true, ...result, stats: mlModel.getModelStats() });
  } catch (error: unknown) {
    res.status(500).json({ error: error instanceof Error ? error.message : 'Unknown error' });
  }
});

export default router;
