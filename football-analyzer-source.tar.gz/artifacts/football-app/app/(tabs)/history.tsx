import React, { useCallback, useEffect, useState } from 'react';
import {
  View, Text, StyleSheet, Pressable, FlatList,
  ActivityIndicator, Platform, Alert,
} from 'react-native';
import { router } from 'expo-router';
import { Ionicons, Feather, MaterialCommunityIcons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useFocusEffect } from 'expo-router';
import { Colors } from '../../constants/colors';
import { getApiUrl } from '../../lib/api';

const HISTORY_KEY = '@footstats_analysis_history';

export interface HistoryEntry {
  id: string;
  matchId: number | string;
  homeTeam: string;
  awayTeam: string;
  homeResult?: number | null;
  awayResult?: number | null;
  statusName?: string;
  league?: string;
  homeWinPct: number;
  drawPct: number;
  awayWinPct: number;
  confidenceScore: number;
  mostLikelyScore: string;
  viewedAt: string;
  mlModelVersion?: number;
}

export async function loadHistory(): Promise<HistoryEntry[]> {
  try {
    const raw = await AsyncStorage.getItem(HISTORY_KEY);
    if (!raw) return [];
    return JSON.parse(raw) as HistoryEntry[];
  } catch {
    return [];
  }
}

export async function saveToHistory(entry: Omit<HistoryEntry, 'id' | 'viewedAt'>): Promise<void> {
  try {
    const existing = await loadHistory();
    const id = `${entry.matchId}_${Date.now()}`;
    const newEntry: HistoryEntry = { ...entry, id, viewedAt: new Date().toISOString() };
    const filtered = existing.filter((e) => e.matchId !== entry.matchId);
    const updated = [newEntry, ...filtered];
    await AsyncStorage.setItem(HISTORY_KEY, JSON.stringify(updated));
  } catch (err) {
    console.error('[History] Failed to save:', err);
  }
}

export async function clearHistory(): Promise<void> {
  await AsyncStorage.removeItem(HISTORY_KEY);
}

export async function syncHistoryToModel(apiBase: string): Promise<void> {
  try {
    const history = await loadHistory();
    const finished = history.filter(
      (e) =>
        e.homeResult !== null &&
        e.homeResult !== undefined &&
        e.awayResult !== null &&
        e.awayResult !== undefined
    );
    if (finished.length === 0) return;
    const entries = finished.map((e) => ({
      matchId: e.matchId,
      homeTeam: e.homeTeam,
      awayTeam: e.awayTeam,
      homeResult: e.homeResult as number,
      awayResult: e.awayResult as number,
      homeWinPct: e.homeWinPct,
      drawPct: e.drawPct,
      awayWinPct: e.awayWinPct,
    }));
    await fetch(`${apiBase}/api/ml/train-from-history`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ entries }),
    });
  } catch (err) {
    console.warn('[History] Failed to sync to model:', err);
  }
}

function formatRelative(dateStr: string): string {
  const d = new Date(dateStr);
  const now = new Date();
  const diffMs = now.getTime() - d.getTime();
  const diffMin = Math.floor(diffMs / 60000);
  if (diffMin < 1) return 'Just now';
  if (diffMin < 60) return `${diffMin}m ago`;
  const diffH = Math.floor(diffMin / 60);
  if (diffH < 24) return `${diffH}h ago`;
  const diffD = Math.floor(diffH / 24);
  if (diffD < 7) return `${diffD}d ago`;
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
}

function getInitials(name: string): string {
  const parts = name.trim().split(/\s+/);
  if (parts.length === 1) return parts[0].substring(0, 3).toUpperCase();
  return parts.slice(0, 2).map((p) => p[0]).join('').toUpperCase();
}

function WinBadge({ pct, color, label }: { pct: number; color: string; label: string }) {
  return (
    <View style={hStyles.winBadge}>
      <Text style={[hStyles.winPct, { color }]}>{pct.toFixed(0)}%</Text>
      <Text style={hStyles.winLabel}>{label}</Text>
    </View>
  );
}

interface HistoryCardProps { entry: HistoryEntry; onDelete: (id: string) => void }
function HistoryCard({ entry, onDelete }: HistoryCardProps) {
  const finished = entry.homeResult !== null && entry.homeResult !== undefined && entry.awayResult !== null && entry.awayResult !== undefined;

  const handleDelete = () => {
    Alert.alert('Remove from history', 'Remove this match from your history?', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Remove', style: 'destructive', onPress: () => onDelete(entry.id) },
    ]);
  };

  return (
    <Pressable
      style={hStyles.card}
      onPress={() => router.push({ pathname: '/[id]', params: { id: String(entry.matchId) } })}
    >
      <View style={hStyles.cardHeader}>
        <View style={hStyles.leaguePill}>
          <MaterialCommunityIcons name="soccer" size={10} color={Colors.accent} />
          <Text style={hStyles.leagueText} numberOfLines={1}>{entry.league || 'Unknown League'}</Text>
        </View>
        <View style={hStyles.cardHeaderRight}>
          <Text style={hStyles.viewedAt}>{formatRelative(entry.viewedAt)}</Text>
          <Pressable style={hStyles.deleteBtn} onPress={handleDelete} hitSlop={8}>
            <Feather name="x" size={14} color={Colors.textMuted} />
          </Pressable>
        </View>
      </View>

      <View style={hStyles.teams}>
        <View style={hStyles.teamCol}>
          <View style={hStyles.teamAvatar}>
            <Text style={hStyles.teamAvatarText}>{getInitials(entry.homeTeam)}</Text>
          </View>
          <Text style={hStyles.teamName} numberOfLines={2}>{entry.homeTeam}</Text>
        </View>

        <View style={hStyles.scoreArea}>
          {finished ? (
            <>
              <Text style={hStyles.score}>{entry.homeResult} : {entry.awayResult}</Text>
              <Text style={hStyles.scoreLabel}>RESULT</Text>
            </>
          ) : (
            <>
              <Text style={hStyles.predicted}>{entry.mostLikelyScore}</Text>
              <Text style={hStyles.scoreLabel}>PREDICTED</Text>
            </>
          )}
        </View>

        <View style={[hStyles.teamCol, { alignItems: 'flex-end' }]}>
          <View style={[hStyles.teamAvatar, { backgroundColor: Colors.purpleDim }]}>
            <Text style={hStyles.teamAvatarText}>{getInitials(entry.awayTeam)}</Text>
          </View>
          <Text style={[hStyles.teamName, { textAlign: 'right' }]} numberOfLines={2}>{entry.awayTeam}</Text>
        </View>
      </View>

      <View style={hStyles.probRow}>
        <WinBadge pct={entry.homeWinPct} color={Colors.home} label="Home" />
        <WinBadge pct={entry.drawPct} color={Colors.amber} label="Draw" />
        <WinBadge pct={entry.awayWinPct} color={Colors.away} label="Away" />
      </View>

      <View style={hStyles.cardFooter}>
        <View style={hStyles.confBadge}>
          <MaterialCommunityIcons name="chart-line" size={11} color={Colors.accent} />
          <Text style={hStyles.confText}>{entry.confidenceScore.toFixed(0)}% conf</Text>
        </View>
        {entry.mlModelVersion !== undefined && (
          <View style={hStyles.mlBadge}>
            <MaterialCommunityIcons name="brain" size={11} color={Colors.purpleLight} />
            <Text style={hStyles.mlText}>ML v{entry.mlModelVersion}</Text>
          </View>
        )}
      </View>
    </Pressable>
  );
}

export default function HistoryScreen() {
  const insets = useSafeAreaInsets();
  const [history, setHistory] = useState<HistoryEntry[]>([]);
  const [loading, setLoading] = useState(true);

  const tabBarHeight = Platform.OS === 'web' ? 84 : 80;
  const bottomPad = insets.bottom + tabBarHeight;
  const topPad = insets.top + (Platform.OS === 'web' ? 67 : 0);

  const reload = useCallback(async () => {
    setLoading(true);
    const data = await loadHistory();
    setHistory(data);
    setLoading(false);
    syncHistoryToModel(getApiUrl()).catch(() => {});
  }, []);

  useFocusEffect(useCallback(() => { reload(); }, [reload]));

  const handleDelete = useCallback(async (id: string) => {
    const updated = history.filter((e) => e.id !== id);
    setHistory(updated);
    await AsyncStorage.setItem(HISTORY_KEY, JSON.stringify(updated));
  }, [history]);

  const handleClearAll = useCallback(() => {
    Alert.alert('Clear all history', 'This will remove all analyzed matches from your history.', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Clear all', style: 'destructive', onPress: async () => {
          await clearHistory();
          setHistory([]);
        },
      },
    ]);
  }, []);

  return (
    <View style={[hStyles.container, { paddingTop: topPad }]}>
      <View style={hStyles.header}>
        <View style={hStyles.headerLeft}>
          <Feather name="clock" size={20} color={Colors.accent} />
          <Text style={hStyles.headerTitle}>History</Text>
        </View>
        <View style={hStyles.headerRight}>
          {history.length > 0 && (
            <>
              <Text style={hStyles.historyCount}>{history.length} analyzed</Text>
              <Pressable style={hStyles.clearBtn} onPress={handleClearAll}>
                <Text style={hStyles.clearText}>Clear</Text>
              </Pressable>
            </>
          )}
        </View>
      </View>

      {loading ? (
        <View style={hStyles.centered}>
          <ActivityIndicator color={Colors.accent} />
        </View>
      ) : history.length === 0 ? (
        <View style={hStyles.centered}>
          <MaterialCommunityIcons name="history" size={52} color={Colors.textMuted} />
          <Text style={hStyles.emptyTitle}>No history yet</Text>
          <Text style={hStyles.emptySubtitle}>Analyze matches to see them here</Text>
          <Pressable style={hStyles.browseBtn} onPress={() => router.push('/')}>
            <Text style={hStyles.browseBtnText}>Browse Matches</Text>
          </Pressable>
        </View>
      ) : (
        <FlatList
          data={history}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => <HistoryCard entry={item} onDelete={handleDelete} />}
          contentContainerStyle={[hStyles.list, { paddingBottom: bottomPad }]}
          showsVerticalScrollIndicator={false}
        />
      )}
    </View>
  );
}

const hStyles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 16, paddingVertical: 10,
  },
  headerLeft: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  headerTitle: { fontFamily: 'Inter_700Bold', fontSize: 22, color: Colors.text },
  headerRight: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  historyCount: { fontFamily: 'Inter_400Regular', fontSize: 12, color: Colors.textMuted },
  clearBtn: { paddingHorizontal: 10, paddingVertical: 5, backgroundColor: Colors.redDim, borderRadius: 8 },
  clearText: { fontFamily: 'Inter_500Medium', fontSize: 12, color: Colors.red },
  centered: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 12 },
  emptyTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 18, color: Colors.textSecondary },
  emptySubtitle: { fontFamily: 'Inter_400Regular', fontSize: 14, color: Colors.textMuted, textAlign: 'center' },
  browseBtn: { marginTop: 8, backgroundColor: Colors.accent, paddingHorizontal: 24, paddingVertical: 12, borderRadius: 12 },
  browseBtnText: { fontFamily: 'Inter_600SemiBold', fontSize: 15, color: '#fff' },
  list: { paddingHorizontal: 12, paddingTop: 8 },
  card: {
    backgroundColor: Colors.bgCard, borderRadius: 14, padding: 14, marginBottom: 10,
    borderWidth: 1, borderColor: Colors.border,
  },
  cardHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 },
  leaguePill: { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: Colors.accentDim, paddingHorizontal: 8, paddingVertical: 3, borderRadius: 8, maxWidth: '70%' },
  leagueText: { fontFamily: 'Inter_500Medium', fontSize: 11, color: Colors.accent },
  cardHeaderRight: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  viewedAt: { fontFamily: 'Inter_400Regular', fontSize: 11, color: Colors.textMuted },
  deleteBtn: { padding: 4 },
  teams: { flexDirection: 'row', alignItems: 'flex-start', marginBottom: 12 },
  teamCol: { flex: 1, alignItems: 'flex-start' },
  teamAvatar: {
    width: 40, height: 40, borderRadius: 10, backgroundColor: Colors.blueDim,
    alignItems: 'center', justifyContent: 'center', marginBottom: 4,
  },
  teamAvatarText: { fontFamily: 'Inter_700Bold', fontSize: 12, color: Colors.text },
  teamName: { fontFamily: 'Inter_500Medium', fontSize: 12, color: Colors.text, lineHeight: 16 },
  scoreArea: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 4 },
  score: { fontFamily: 'Inter_700Bold', fontSize: 22, color: Colors.text },
  predicted: { fontFamily: 'Inter_700Bold', fontSize: 22, color: Colors.textSecondary },
  scoreLabel: { fontFamily: 'Inter_400Regular', fontSize: 10, color: Colors.textMuted, marginTop: 2 },
  probRow: { flexDirection: 'row', justifyContent: 'space-around', backgroundColor: Colors.bgCardDark, borderRadius: 10, paddingVertical: 10, marginBottom: 10 },
  winBadge: { alignItems: 'center', gap: 2 },
  winPct: { fontFamily: 'Inter_700Bold', fontSize: 16 },
  winLabel: { fontFamily: 'Inter_400Regular', fontSize: 10, color: Colors.textMuted },
  cardFooter: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  confBadge: { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: Colors.accentDim, paddingHorizontal: 8, paddingVertical: 3, borderRadius: 6 },
  confText: { fontFamily: 'Inter_500Medium', fontSize: 11, color: Colors.accent },
  mlBadge: { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: Colors.purpleDim, paddingHorizontal: 8, paddingVertical: 3, borderRadius: 6 },
  mlText: { fontFamily: 'Inter_500Medium', fontSize: 11, color: Colors.purpleLight },
});
